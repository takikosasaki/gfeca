# Revision log for SupplementaryData

Updated to match `elsarticle-tn_v2.tex`.

- Convex mixing is described as an appendix-level illustrative extension, not as a main-text contribution.
- Rule 210 figure-numbered data files were renamed from the old Fig. 17--20 numbering to the revised Fig. 14--17 numbering.
- README files were updated consistently.
- The internal random-seed tags in the Rule 210 generation script are kept compatible with the previously generated CSV data.

(* ::Package:: *)

(*
  Rule 210 three-cell GFDNF: three-class replacement for Figs. 14--17.

  This script redraws Figs. 14--17 using the classification

      +1 : convergence to the first stable period-six cycle P
      -1 : convergence to the symmetric stable period-six cycle P'
       2 : capture by the cyclic invariant line set L
       3 : capture by the larger coordinate-plane set only (diagnostic)
       0 : still unclassified

  The line set is

      L = {(x,1/2,1/2)} U {(1/2,x,1/2)} U {(1/2,1/2,x)}.

  Main outputs:
      fig14_threeclass_z0p5.pdf / png
      fig15_threeclass_z0p3.pdf / png
      fig14_components_z0p5.pdf / png
      fig15_components_z0p3.pdf / png
      fig16_threeclass_uncertainty.pdf / png
      fig17_threeclass_entropy_main.pdf / png
      fig17_threeclass_entropy_resolution_sweep.pdf / png

  CSV outputs:
      fig14_15_basin_slice_counts.csv
      fig16_threeclass_uncertainty_by_seed.csv
      fig16_threeclass_uncertainty_pooled.csv
      fig16_threeclass_uncertainty_fit_summary.csv
      fig17_threeclass_entropy_summary.csv
      fig17_threeclass_main_values.csv

  Usage in Mathematica:
      Get["C:/path/to/rule210_fig14_17_threeclass_revised.wl"]

  For a quick run, set quickTest = True below. For full run False.
*)

ClearAll["Global`*"];
$HistoryLength = 0;

(* ------------------------------------------------------------------------- *)
(* User settings                                                             *)
(* ------------------------------------------------------------------------- *)

quickTest = False;

runFig14and15 = True;
runFig16 = True;
runFig17 = True;

(* Use a local folder outside OneDrive by default.  Set outputRootOverride =
   Automatic to create output next to the current notebook/script. *)
outputRootOverride = FileNameJoin[{$HomeDirectory, "GFECA_results"}];

(* Classification settings. *)
zSlices = {0.5, 0.3};
maxIterations = 20000;
cycleDelta = 10^-6;
lineDelta = 10^-10;
planeDelta = 10^-10;
stayPeriods = 20;
checkEvery = 6;
roundingEpsilon = 10^-14;

(* Fig. 14--15 basin-slice image settings. *)
basinImageGrid = 800;               (* 800 gives manuscript-quality slices. *)
exportLargeLabelArrays = True;       (* True exports WXF label arrays, so figures can be redrawn without recomputation. *)

(* Fig. 16 uncertainty-exponent settings. *)
epsilonList = N[10^Range[-4, -1, 1/4]];
pairsPerEpsilon = 10000;
uncertaintySeeds = Range[20260316, 20260320];
fitEpsilonRange = {10^-4, 10^-1};

(* Fig. 17 class-entropy settings. *)
entropyBoxesList = {40, 80, 160};
entropySamplesPerBoxList = {10, 20, 50};
entropySeeds = {20260316};
entropyMainBoxes = 80;
entropyMainSamplesPerBox = 20;

(* Figure style settings. These affect only plotting, not the numerical data. *)
figBaseFont = 18;
figTickFont = 16;
figLabelFont = 20;
figTitleFont = 22;
figLegendFont = 18;
figAnnotationFont = 15;
figFontFamily = "Arial";

If[quickTest,
  basinImageGrid = 160;
  epsilonList = N[10^Range[-3, -1, 1/2]];
  pairsPerEpsilon = 200;
  uncertaintySeeds = {20260316};
  maxIterations = 5000;
  stayPeriods = 5;
  entropyBoxesList = {20, 40};
  entropySamplesPerBoxList = {3, 5};
  entropyMainBoxes = 40;
  entropyMainSamplesPerBox = 5;
];

(* ------------------------------------------------------------------------- *)
(* Output directory and safe export                                          *)
(* ------------------------------------------------------------------------- *)

baseDir = If[outputRootOverride === Automatic,
   Quiet@Check[NotebookDirectory[], Directory[]],
   outputRootOverride
];
If[baseDir === $Failed || ! StringQ[baseDir], baseDir = Directory[]];
If[! DirectoryQ[baseDir], CreateDirectory[baseDir, CreateIntermediateDirectories -> True]];

timeStamp = DateString[{"Year", "Month", "Day", "_", "Hour", "Minute", "Second"}];
outDir = FileNameJoin[{baseDir, "rule210_fig14_17_threeclass_" <> timeStamp}];
CreateDirectory[outDir, CreateIntermediateDirectories -> True];
Print["Output directory: ", outDir];

ClearAll[safeExport];
safeExport[file_String, expr_, fmt_: Automatic, opts___] := Module[{dir, res},
  dir = DirectoryName[file];
  If[StringQ[dir] && ! DirectoryQ[dir], CreateDirectory[dir, CreateIntermediateDirectories -> True]];
  res = Quiet@Check[
    If[fmt === Automatic, Export[file, expr, opts], Export[file, expr, fmt, opts]],
    $Failed
  ];
  If[res === $Failed, Print["WARNING: export failed: ", file]];
  res
];

ClearAll[exportFigure];
exportFigure[name_String, g_] := Module[{pdf, png, img},
  pdf = FileNameJoin[{outDir, name <> ".pdf"}];
  png = FileNameJoin[{outDir, name <> ".png"}];
  (* Rasterizing before PDF export avoids the bounding-box/cropping problem
     that can occur for BarChart, Legended, GraphicsRow, or GraphicsGrid. *)
  img = Rasterize[g, "Image", ImageResolution -> 300];
  safeExport[pdf, img, "PDF"];
  safeExport[png, img, "PNG"];
];

configAssoc = <|
  "QuickTest" -> quickTest,
  "ZSlices" -> zSlices,
  "MaxIterations" -> maxIterations,
  "CycleDelta" -> cycleDelta,
  "LineDelta" -> lineDelta,
  "PlaneDelta" -> planeDelta,
  "StayPeriods" -> stayPeriods,
  "CheckEvery" -> checkEvery,
  "RoundingEpsilon" -> roundingEpsilon,
  "BasinImageGrid" -> basinImageGrid,
  "EpsilonList" -> epsilonList,
  "PairsPerEpsilon" -> pairsPerEpsilon,
  "UncertaintySeeds" -> uncertaintySeeds,
  "FitEpsilonRange" -> fitEpsilonRange,
  "EntropyBoxesList" -> entropyBoxesList,
  "EntropySamplesPerBoxList" -> entropySamplesPerBoxList,
  "EntropySeeds" -> entropySeeds,
  "EntropyMainBoxes" -> entropyMainBoxes,
  "EntropyMainSamplesPerBox" -> entropyMainSamplesPerBox
|>;

Put[configAssoc, FileNameJoin[{outDir, "config.wl"}]];
safeExport[FileNameJoin[{outDir, "metadata.json"}],
  <|"Date" -> DateString["ISODateTime"], "WolframVersion" -> $Version,
    "SystemID" -> $SystemID, "Config" -> configAssoc|>,
  "JSON"
];

(* ------------------------------------------------------------------------- *)
(* Rule 210 map, period-six cycles, and distances                            *)
(* ------------------------------------------------------------------------- *)

aStar = 0.4785350944;
bStar = 0.6235572234;
cStar = 0.2907948676;
dStar = 0.5560666557;

cyclePlus = N[{
   {aStar, 1/2, bStar},
   {cStar, dStar, 1/2},
   {1/2, bStar, aStar},
   {dStar, 1/2, cStar},
   {bStar, aStar, 1/2},
   {1/2, cStar, dStar}
}];

cycleMinus = N[{
   {1 - bStar, 1/2, 1 - aStar},
   {1 - dStar, 1 - cStar, 1/2},
   {1/2, 1 - aStar, 1 - bStar},
   {1 - cStar, 1/2, 1 - dStar},
   {1 - aStar, 1 - bStar, 1/2},
   {1/2, 1 - dStar, 1 - cStar}
}];

ClearAll[uStar, f210, T210Step, lineDistance, planeDistance, minCycleDistance];
uStar[x_?NumericQ] := Which[x <= 1/3, 3 x, x <= 2/3, 2 - 3 x, True, 3 x - 2];
f210[X_?NumericQ, Y_?NumericQ, Z_?NumericQ] := 2 X Y Z - 2 X Z + X - Y Z + Z;
T210Step[{x_?NumericQ, y_?NumericQ, z_?NumericQ}] := Module[{ux, uy, uz},
  ux = uStar[x]; uy = uStar[y]; uz = uStar[z];
  {f210[uz, ux, uy], f210[ux, uy, uz], f210[uy, uz, ux]}
];
lineDistance[{x_?NumericQ, y_?NumericQ, z_?NumericQ}] := Min[
  Max[Abs[y - 1/2], Abs[z - 1/2]],
  Max[Abs[x - 1/2], Abs[z - 1/2]],
  Max[Abs[x - 1/2], Abs[y - 1/2]]
];
planeDistance[{x_?NumericQ, y_?NumericQ, z_?NumericQ}] := Min[Abs[x - 1/2], Abs[y - 1/2], Abs[z - 1/2]];
minCycleDistance[pt_List, cyc_List] := Min[Norm[pt - #, Infinity] & /@ cyc];

Print["max one-step cycle error, plus cycle = ",
  Max[Table[Norm[T210Step[cyclePlus[[i]]] - cyclePlus[[Mod[i, 6] + 1]], Infinity], {i, 1, 6}]]
];
Print["max one-step cycle error, minus cycle = ",
  Max[Table[Norm[T210Step[cycleMinus[[i]]] - cycleMinus[[Mod[i, 6] + 1]], Infinity], {i, 1, 6}]]
];

(* ------------------------------------------------------------------------- *)
(* Compiled three-class classifier                                           *)
(* ------------------------------------------------------------------------- *)

compiledClassifyThree = With[
  {cp = cyclePlus, cm = cycleMinus, oneThird = N[1/3], twoThird = N[2/3]},
  Compile[
    {
      {x0, _Real}, {y0, _Real}, {z0, _Real},
      {maxIter, _Integer}, {cycDelta, _Real},
      {linDelta, _Real}, {plnDelta, _Real},
      {stay, _Integer}, {check, _Integer}, {roundEps, _Real}
    },
    Module[
      {
        x = x0, y = y0, z = z0,
        ux = 0., uy = 0., uz = 0., nx = 0., ny = 0., nz = 0.,
        i = 0, j = 0, plusCount = 0, minusCount = 0, lineCount = 0, planeCount = 0,
        label = 0, stopIter = 0,
        dx = 0., dy = 0., dz = 0., dist = 0.,
        minPlus = 1.*^100, minMinus = 1.*^100,
        dLine = 1.*^100, dPlane = 1.*^100,
        finalPlus = 1.*^100, finalMinus = 1.*^100,
        minLineEver = 1.*^100, minPlaneEver = 1.*^100,
        tmp1 = 0., tmp2 = 0., tmp3 = 0.
      },

      For[i = 1, i <= maxIter, i++,
        ux = If[x <= oneThird, 3. x, If[x <= twoThird, -3. x + 2., 3. x - 2.]];
        uy = If[y <= oneThird, 3. y, If[y <= twoThird, -3. y + 2., 3. y - 2.]];
        uz = If[z <= oneThird, 3. z, If[z <= twoThird, -3. z + 2., 3. z - 2.]];

        nx = 2. uz ux uy - 2. uz uy + uz - ux uy + uy;
        ny = 2. ux uy uz - 2. ux uz + ux - uy uz + uz;
        nz = 2. uy uz ux - 2. uy ux + uy - uz ux + ux;

        x = If[nx <= roundEps, 0., If[nx >= 1. - roundEps, 1., nx]];
        y = If[ny <= roundEps, 0., If[ny >= 1. - roundEps, 1., ny]];
        z = If[nz <= roundEps, 0., If[nz >= 1. - roundEps, 1., nz]];

        If[Mod[i, check] == 0,
          (* Distance to plus cycle. *)
          minPlus = 1.*^100;
          For[j = 1, j <= 6, j++,
            dx = Abs[x - cp[[j, 1]]]; dy = Abs[y - cp[[j, 2]]]; dz = Abs[z - cp[[j, 3]]];
            dist = Max[dx, dy, dz];
            If[dist < minPlus, minPlus = dist];
          ];

          (* Distance to minus cycle. *)
          minMinus = 1.*^100;
          For[j = 1, j <= 6, j++,
            dx = Abs[x - cm[[j, 1]]]; dy = Abs[y - cm[[j, 2]]]; dz = Abs[z - cm[[j, 3]]];
            dist = Max[dx, dy, dz];
            If[dist < minMinus, minMinus = dist];
          ];

          If[minPlus < cycDelta && minPlus < minMinus,
            plusCount = plusCount + 1; minusCount = 0,
            If[minMinus < cycDelta && minMinus < minPlus,
              minusCount = minusCount + 1; plusCount = 0,
              plusCount = 0; minusCount = 0
            ]
          ];

          tmp1 = Max[Abs[y - 0.5], Abs[z - 0.5]];
          tmp2 = Max[Abs[x - 0.5], Abs[z - 0.5]];
          tmp3 = Max[Abs[x - 0.5], Abs[y - 0.5]];
          dLine = Min[tmp1, Min[tmp2, tmp3]];
          dPlane = Min[Abs[x - 0.5], Min[Abs[y - 0.5], Abs[z - 0.5]]];

          If[dLine < minLineEver, minLineEver = dLine];
          If[dPlane < minPlaneEver, minPlaneEver = dPlane];

          If[dLine < linDelta, lineCount = lineCount + 1, lineCount = 0];
          If[dPlane < plnDelta, planeCount = planeCount + 1, planeCount = 0];

          If[plusCount >= stay,
            label = 1; stopIter = i; i = maxIter + 1;
          ];
          If[minusCount >= stay,
            label = -1; stopIter = i; i = maxIter + 1;
          ];
          If[label == 0 && lineCount >= stay,
            label = 2; stopIter = i; i = maxIter + 1;
          ];
        ];
      ];

      (* Final distances. *)
      tmp1 = Max[Abs[y - 0.5], Abs[z - 0.5]];
      tmp2 = Max[Abs[x - 0.5], Abs[z - 0.5]];
      tmp3 = Max[Abs[x - 0.5], Abs[y - 0.5]];
      dLine = Min[tmp1, Min[tmp2, tmp3]];
      dPlane = Min[Abs[x - 0.5], Min[Abs[y - 0.5], Abs[z - 0.5]]];

      finalPlus = 1.*^100;
      For[j = 1, j <= 6, j++,
        dx = Abs[x - cp[[j, 1]]]; dy = Abs[y - cp[[j, 2]]]; dz = Abs[z - cp[[j, 3]]];
        dist = Max[dx, dy, dz];
        If[dist < finalPlus, finalPlus = dist];
      ];
      finalMinus = 1.*^100;
      For[j = 1, j <= 6, j++,
        dx = Abs[x - cm[[j, 1]]]; dy = Abs[y - cm[[j, 2]]]; dz = Abs[z - cm[[j, 3]]];
        dist = Max[dx, dy, dz];
        If[dist < finalMinus, finalMinus = dist];
      ];

      If[label == 0,
        If[lineCount >= stay,
          label = 2,
          If[planeCount >= stay, label = 3, label = 0]
        ];
      ];

      {N[label], dLine, dPlane, finalPlus, finalMinus, minLineEver, minPlaneEver,
       If[stopIter > 0, N[stopIter], N[maxIter]]}
    ],
    RuntimeOptions -> "Speed",
    CompilationTarget -> "WVM"
  ]
];

ClearAll[classifyLabel, classifyDetailed];
classifyDetailed[pt_List] := compiledClassifyThree[
  N[pt[[1]]], N[pt[[2]]], N[pt[[3]]],
  maxIterations, N[cycleDelta], N[lineDelta], N[planeDelta],
  stayPeriods, checkEvery, N[roundingEpsilon]
];
classifyLabel[pt_List] := Round[classifyDetailed[pt][[1]]];

(* ------------------------------------------------------------------------- *)
(* Deterministic random seeds                                                *)
(* ------------------------------------------------------------------------- *)

ClearAll[makeSeed];
makeSeed[args___] := Module[{s, h},
  s = ToString[HoldComplete[args], InputForm];
  h = Quiet@Check[Hash[s, "SHA256"], Hash[s]];
  Mod[Abs[h], 2147483646] + 1
];

(* ------------------------------------------------------------------------- *)
(* Common plotting helpers                                                   *)
(* ------------------------------------------------------------------------- *)

labelColorRules = {
  1 -> Black,
  -1 -> GrayLevel[0.65],
  2 -> RGBColor[0.1, 0.32, 0.85],
  3 -> RGBColor[0.35, 0.78, 0.95],
  0 -> RGBColor[0.85, 0.1, 0.1]
};

labelNames = <|1 -> "P-cycle", -1 -> "P'-cycle", 2 -> "line set L", 3 -> "plane only", 0 -> "other"|>;

ClearAll[legendGraphic];
legendGraphic[] := SwatchLegend[
  {Black, GrayLevel[0.65], RGBColor[0.1, 0.32, 0.85], RGBColor[0.85, 0.1, 0.1]},
  {"P-cycle", "P'-cycle", "line set L", "other"},
  LegendLayout -> "Row"
];

ClearAll[countLabels];
countLabels[labels_] := Module[{flat, c, total},
  flat = Flatten[labels];
  c = Counts[flat];
  total = Length[flat];
  <|
    "Plus" -> Lookup[c, 1, 0],
    "Minus" -> Lookup[c, -1, 0],
    "Line" -> Lookup[c, 2, 0],
    "PlaneOnly" -> Lookup[c, 3, 0],
    "Other" -> Lookup[c, 0, 0],
    "Total" -> total,
    "PlusFraction" -> N[Lookup[c, 1, 0]/total],
    "MinusFraction" -> N[Lookup[c, -1, 0]/total],
    "LineFraction" -> N[Lookup[c, 2, 0]/total],
    "PlaneOnlyFraction" -> N[Lookup[c, 3, 0]/total],
    "OtherFraction" -> N[Lookup[c, 0, 0]/total]
  |>
];

(* ------------------------------------------------------------------------- *)
(* Fig. 14--15: three-class basin/class slices                                *)
(* ------------------------------------------------------------------------- *)

ClearAll[computeSliceLabels, sliceArrayPlot, componentPlot];
computeSliceLabels[z0_?NumericQ, n_Integer] := Module[{mat, x, y},
  Print["Computing slice labels: z=", z0, ", grid=", n, " x ", n];
  mat = Table[
    y = (iy - 0.5)/n;
    Table[
      x = (ix - 0.5)/n;
      classifyLabel[{x, y, z0}],
      {ix, 1, n}
    ],
    {iy, n, 1, -1}
  ];
  mat
];

sliceArrayPlot[mat_, title_String] := Legended[
  ArrayPlot[
    mat,
    ColorRules -> labelColorRules,
    Frame -> True,
    (* ArrayPlot columns are x and rows are y; nested FrameLabel avoids reversed labels. *)
    FrameLabel -> {{Style["y", figLabelFont, FontFamily -> figFontFamily], None},
                   {Style["x", figLabelFont, FontFamily -> figFontFamily], None}},
    FrameTicks -> {{Table[{1 + (Length[mat] - 1) (1 - v), Style[NumberForm[v, {2, 1}], figTickFont]}, {v, 0, 1, 0.5}], None},
                   {Table[{1 + (Length[mat[[1]]] - 1) v, Style[NumberForm[v, {2, 1}], figTickFont]}, {v, 0, 1, 0.5}], None}},
    PlotLabel -> Style[title, figTitleFont, Bold, FontFamily -> figFontFamily],
    ImageSize -> 620,
    ImagePadding -> {{85, 25}, {85, 55}},
    BaseStyle -> {FontSize -> figBaseFont, FontFamily -> figFontFamily},
    PlotRangePadding -> None
  ],
  Placed[legendGraphic[], Below]
];

componentPlot[mat_, title_String] := Module[{plus, minus, line, other, mk, panelSize},
  panelSize = 300;
  mk[val_] := Map[If[# == val, 1, 0] &, mat, {2}];
  plus = mk[1]; minus = mk[-1]; line = mk[2]; other = Map[If[MemberQ[{0, 3}, #], 1, 0] &, mat, {2}];
  GraphicsGrid[
    {{
      ArrayPlot[plus, ColorRules -> {0 -> White, 1 -> Black}, Frame -> False,
        PlotLabel -> Style["P-cycle", figTitleFont - 2, FontFamily -> figFontFamily], ImageSize -> panelSize],
      ArrayPlot[minus, ColorRules -> {0 -> White, 1 -> GrayLevel[0.55]}, Frame -> False,
        PlotLabel -> Style["P'-cycle", figTitleFont - 2, FontFamily -> figFontFamily], ImageSize -> panelSize]
    },{
      ArrayPlot[line, ColorRules -> {0 -> White, 1 -> RGBColor[0.1, 0.32, 0.85]}, Frame -> False,
        PlotLabel -> Style["line set L", figTitleFont - 2, FontFamily -> figFontFamily], ImageSize -> panelSize],
      ArrayPlot[other, ColorRules -> {0 -> White, 1 -> RGBColor[0.85, 0.1, 0.1]}, Frame -> False,
        PlotLabel -> Style["other", figTitleFont - 2, FontFamily -> figFontFamily], ImageSize -> panelSize]
    }},
    Spacings -> {0.25, 0.25},
    PlotLabel -> Style[title, figTitleFont, Bold, FontFamily -> figFontFamily],
    ImageSize -> 690
  ]
];

basinSliceCounts = {};
basinSliceData = <||>;

If[runFig14and15,
  Do[
    Module[{mat, counts, zTag, title, mainFig, compFig},
      mat = computeSliceLabels[z0, basinImageGrid];
      counts = countLabels[mat];
      zTag = If[Abs[z0 - 0.5] < 10^-12, "z0p5", "z0p3"];
      basinSliceData[zTag] = mat;
      basinSliceCounts = Append[basinSliceCounts,
        Join[<|"z" -> z0, "Grid" -> basinImageGrid|>, counts]
      ];
      If[exportLargeLabelArrays,
        safeExport[FileNameJoin[{outDir, "fig14_15_labels_" <> zTag <> ".wxf"}], mat, "WXF"]
      ];
      title = "Rule 210 three-class slice, z = " <> If[z0 == 0.5, "1/2", ToString[z0]];
      mainFig = sliceArrayPlot[mat, title];
      compFig = componentPlot[mat, title <> " components"];
      If[z0 == 0.5,
        exportFigure["fig14_threeclass_z0p5", mainFig];
        exportFigure["fig14_components_z0p5", compFig],
        exportFigure["fig15_threeclass_z0p3", mainFig];
        exportFigure["fig15_components_z0p3", compFig]
      ];
    ],
    {z0, zSlices}
  ];
  safeExport[FileNameJoin[{outDir, "fig14_15_basin_slice_counts.csv"}],
    Prepend[(Values /@ basinSliceCounts), Keys[First[basinSliceCounts]]], "CSV"];
];

(* ------------------------------------------------------------------------- *)
(* Fig. 16: three-class uncertainty exponent                                 *)
(* The seed tags below keep the pre-renumbering labels (fig19/fig20) so that
   rerunning this script reproduces the archived CSV values after the manuscript
   figure renumbering. *)
(* ------------------------------------------------------------------------- *)

ClearAll[randomPairInSlice, estimateUncertaintyCase, poolUncertaintyRows, fitPowerLaw];

randomPairInSlice[z0_?NumericQ, eps_?NumericQ] := Module[{p1, theta, p2, tries = 0},
  While[True,
    p1 = RandomReal[{0, 1}, 2];
    theta = RandomReal[{0, 2 Pi}];
    p2 = p1 + eps {Cos[theta], Sin[theta]};
    tries++;
    If[Min[p2] >= 0 && Max[p2] <= 1,
      Return[{{p1[[1]], p1[[2]], z0}, {p2[[1]], p2[[2]], z0}, tries}]
    ];
    If[tries > 10000, Return[$Failed]];
  ]
];

estimateUncertaintyCase[z0_?NumericQ, eps_?NumericQ, seed_Integer] := Module[
  {nPairs = pairsPerEpsilon, same = 0, diff = 0, other = 0,
   sameCycle = 0, diffCycle = 0, otherCycle = 0,
   pair, lab1, lab2, used3, usedCycle, linePair = 0, triesTotal = 0},
  BlockRandom[
    SeedRandom[makeSeed["fig19-threeclass", z0, eps, seed, maxIterations, cycleDelta, lineDelta]];
    Do[
      pair = randomPairInSlice[z0, eps];
      If[pair === $Failed,
        other++,
        triesTotal += pair[[3]];
        lab1 = classifyLabel[pair[[1]]];
        lab2 = classifyLabel[pair[[2]]];
        If[lab1 == 2 || lab2 == 2, linePair++];

        used3 = MemberQ[{1, -1, 2}, lab1] && MemberQ[{1, -1, 2}, lab2];
        If[used3,
          If[lab1 == lab2, same++, diff++],
          other++
        ];

        usedCycle = MemberQ[{1, -1}, lab1] && MemberQ[{1, -1}, lab2];
        If[usedCycle,
          If[lab1 == lab2, sameCycle++, diffCycle++],
          otherCycle++
        ];
      ],
      {nPairs}
    ];
  ];
  Module[{usable = same + diff, usableCycle = sameCycle + diffCycle, p3, se3, ppm, sepm},
    p3 = If[usable > 0, N[diff/usable], Indeterminate];
    se3 = If[usable > 0, Sqrt[p3 (1 - p3)/usable], Indeterminate];
    ppm = If[usableCycle > 0, N[diffCycle/usableCycle], Indeterminate];
    sepm = If[usableCycle > 0, Sqrt[ppm (1 - ppm)/usableCycle], Indeterminate];
    <|
      "z" -> z0, "Epsilon" -> eps, "Seed" -> seed, "Pairs" -> nPairs,
      "UsablePairs3" -> usable, "DifferentPairs3" -> diff, "SamePairs3" -> same,
      "OtherPairs3" -> other, "P3" -> p3, "BinomialSE3" -> se3,
      "OtherPairFraction3" -> N[other/nPairs], "LinePairFraction" -> N[linePair/nPairs],
      "UsablePairsCycleOnly" -> usableCycle, "DifferentPairsCycleOnly" -> diffCycle,
      "SamePairsCycleOnly" -> sameCycle, "OtherPairsCycleOnly" -> otherCycle,
      "PCycleOnly" -> ppm, "BinomialSECycleOnly" -> sepm,
      "OtherPairFractionCycleOnly" -> N[otherCycle/nPairs],
      "MeanRejectTries" -> N[triesTotal/nPairs]
    |>
  ]
];

poolUncertaintyRows[rows_List] := Module[{groups},
  groups = GatherBy[rows, {#["z"], #["Epsilon"]} &];
  Map[
    Function[g,
      Module[{first = First[g], pairs, usable, diff, same, other, linePairs,
              usableC, diffC, sameC, otherC, p3, se3, pc, sec},
        pairs = Total[(#["Pairs"] & /@ g)];
        usable = Total[(#["UsablePairs3"] & /@ g)];
        diff = Total[(#["DifferentPairs3"] & /@ g)];
        same = Total[(#["SamePairs3"] & /@ g)];
        other = Total[(#["OtherPairs3"] & /@ g)];
        linePairs = Total[Round[(#["LinePairFraction"] #["Pairs"] & /@ g)]];
        usableC = Total[(#["UsablePairsCycleOnly"] & /@ g)];
        diffC = Total[(#["DifferentPairsCycleOnly"] & /@ g)];
        sameC = Total[(#["SamePairsCycleOnly"] & /@ g)];
        otherC = Total[(#["OtherPairsCycleOnly"] & /@ g)];
        p3 = If[usable > 0, N[diff/usable], Indeterminate];
        se3 = If[usable > 0, Sqrt[p3 (1 - p3)/usable], Indeterminate];
        pc = If[usableC > 0, N[diffC/usableC], Indeterminate];
        sec = If[usableC > 0, Sqrt[pc (1 - pc)/usableC], Indeterminate];
        <|
          "z" -> first["z"], "Epsilon" -> first["Epsilon"],
          "Seeds" -> Length[g], "Pairs" -> pairs,
          "UsablePairs3" -> usable, "DifferentPairs3" -> diff, "SamePairs3" -> same,
          "OtherPairs3" -> other, "P3" -> p3, "BinomialSE3" -> se3,
          "OtherPairFraction3" -> N[other/pairs], "LinePairFraction" -> N[linePairs/pairs],
          "UsablePairsCycleOnly" -> usableC, "DifferentPairsCycleOnly" -> diffC,
          "SamePairsCycleOnly" -> sameC, "OtherPairsCycleOnly" -> otherC,
          "PCycleOnly" -> pc, "BinomialSECycleOnly" -> sec,
          "OtherPairFractionCycleOnly" -> N[otherC/pairs]
        |>
      ]
    ], groups
  ]
];

fitPowerLaw[dataRows_List, pKey_String] := Module[
  {fitRows, xy, lm, pars, errs, df, q, slope, intercept, se, ci, r2},
  fitRows = Select[dataRows,
    fitEpsilonRange[[1]] <= #["Epsilon"] <= fitEpsilonRange[[2]] && NumericQ[#[pKey]] && #[pKey] > 0 &
  ];
  xy = ({Log10[#["Epsilon"]], Log10[#[pKey]]} & /@ fitRows);
  If[Length[xy] < 3,
    Return[<|"Gamma" -> Indeterminate, "GammaSE" -> Indeterminate,
      "GammaCI95Lower" -> Indeterminate, "GammaCI95Upper" -> Indeterminate,
      "DbEstimate" -> Indeterminate, "R2" -> Indeterminate,
      "NumberOfFitPoints" -> Length[xy]|>]
  ];
  lm = LinearModelFit[xy, x, x];
  pars = lm["BestFitParameters"];
  errs = lm["ParameterErrors"];
  intercept = pars[[1]];
  slope = pars[[2]];
  se = errs[[2]];
  df = Length[xy] - 2;
  q = Quantile[StudentTDistribution[df], 0.975];
  ci = q se;
  r2 = lm["RSquared"];
  <|
    "Intercept" -> intercept,
    "Gamma" -> slope,
    "GammaSE" -> se,
    "GammaCI95Lower" -> slope - ci,
    "GammaCI95Upper" -> slope + ci,
    "DbEstimate" -> 2 - slope,
    "R2" -> r2,
    "NumberOfFitPoints" -> Length[xy]
  |>
];

ClearAll[logTickLabels, makeUncertaintyPanel];
ClearAll[fmtLogTick, logTickLabels];
fmtLogTick[v_] := Module[{e = Round[Log10[N[v]]]},
  If[Abs[Log10[N[v]] - e] < 10^-8,
    Superscript[10, e],
    NumberForm[v, {3, 2}]
  ]
];
logTickLabels[vals_List] := ({Log10[N[#]], Style[fmtLogTick[#], figTickFont, FontFamily -> figFontFamily]} & /@ vals);

makeUncertaintyPanel[rows_, fitAssoc_, z0_] := Module[
  {data, pts, errLines, xmin, xmax, ymin, ymax, xvals, yvals, line, annotation, title},
  data = SortBy[rows, #["Epsilon"] &];
  pts = ({Log10[#["Epsilon"]], Log10[#["P3"]]} & /@ Select[data, NumericQ[#["P3"]] && #["P3"] > 0 &]);
  errLines = Table[
    If[NumericQ[r["BinomialSE3"]] && r["P3"] > r["BinomialSE3"] && r["P3"] + r["BinomialSE3"] < 1,
      Line[{{Log10[r["Epsilon"]], Log10[r["P3"] - r["BinomialSE3"]]},
            {Log10[r["Epsilon"]], Log10[r["P3"] + r["BinomialSE3"]]}}],
      Nothing
    ],
    {r, data}
  ];
  xvals = pts[[All, 1]]; yvals = pts[[All, 2]];
  xmin = Min[xvals] - 0.10; xmax = Max[xvals] + 0.10;
  ymin = Min[yvals] - 0.16; ymax = Max[yvals] + 0.16;
  line[x_] := fitAssoc["Intercept"] + fitAssoc["Gamma"] x;
  annotation = Framed[
    Column[{
      Style["gamma = " <> ToString[NumberForm[fitAssoc["Gamma"], {5, 3}]] <> " +/- " <> ToString[NumberForm[fitAssoc["GammaSE"], {4, 3}]], figAnnotationFont],
      Style["Db = " <> ToString[NumberForm[fitAssoc["DbEstimate"], {5, 3}]], figAnnotationFont],
      Style["R^2 = " <> ToString[NumberForm[fitAssoc["R2"], {5, 3}]], figAnnotationFont],
      Style["line-pair = " <> ToString[NumberForm[Mean[(#["LinePairFraction"] & /@ data)], {4, 3}]], figAnnotationFont],
      Style["other-pair = " <> ToString[NumberForm[Mean[(#["OtherPairFraction3"] & /@ data)], {4, 3}]], figAnnotationFont]
    }, Center, Spacings -> 0.25], Background -> White, FrameStyle -> Black, FrameMargins -> 6
  ];
  title = "z = " <> If[z0 == 0.5, "1/2", ToString[z0]];
  Graphics[
    {
      GrayLevel[0.55], AbsoluteThickness[1.3], errLines,
      Black, Dashed, AbsoluteThickness[2.2], Line[Table[{x, line[x]}, {x, xmin, xmax, (xmax - xmin)/100.}]],
      RGBColor[0.1, 0.32, 0.85], PointSize[0.017], Point[pts],
      Inset[annotation, Scaled[{0.63, 0.30}]]
    },
    Frame -> True,
    FrameLabel -> {{Style["P(\[Epsilon])", figLabelFont, FontFamily -> figFontFamily], None},
                   {Style["separation \[Epsilon]", figLabelFont, FontFamily -> figFontFamily], None}},
    FrameTicks -> {{logTickLabels[{0.02, 0.05, 0.1, 0.2, 0.5, 0.8}], None},
                   {logTickLabels[{10^-4, 10^-3, 10^-2, 10^-1}], None}},
    GridLines -> {Log10 /@ {10^-4, 10^-3, 10^-2, 10^-1}, Log10 /@ {0.05, 0.1, 0.2, 0.5}},
    GridLinesStyle -> Directive[GrayLevel[0.85], Thin],
    PlotRange -> {{xmin, xmax}, {ymin, ymax}},
    ImagePadding -> {{90, 25}, {85, 55}},
    ImageSize -> 610,
    BaseStyle -> {FontSize -> figBaseFont, FontFamily -> figFontFamily},
    PlotLabel -> Style[title, figTitleFont, Bold, FontFamily -> figFontFamily]
  ]
];

uncertaintyRows = {};
uncertaintyPooled = {};
uncertaintyFits = {};

If[runFig16,
  Print["Computing Fig. 16 three-class uncertainty data..."];
  uncertaintyRows = Flatten[
    Table[
      Print["  z=", z0, ", epsilon=", eps, ", seed=", seed];
      estimateUncertaintyCase[z0, eps, seed],
      {z0, zSlices}, {eps, epsilonList}, {seed, uncertaintySeeds}
    ], 2
  ];
  uncertaintyPooled = poolUncertaintyRows[uncertaintyRows];

  uncertaintyFits = Flatten[Table[
    Module[{rows = Select[uncertaintyPooled, #["z"] == z0 &], fit3, fitCycle},
      fit3 = fitPowerLaw[rows, "P3"];
      fitCycle = fitPowerLaw[rows, "PCycleOnly"];
      {
        Join[<|"z" -> z0, "FitType" -> "ThreeClass", "FitEpsilonMin" -> fitEpsilonRange[[1]],
               "FitEpsilonMax" -> fitEpsilonRange[[2]]|>, fit3,
             <|"MeanOtherPairFraction" -> Mean[(#["OtherPairFraction3"] & /@ rows)],
               "MeanLinePairFraction" -> Mean[(#["LinePairFraction"] & /@ rows)]|>],
        Join[<|"z" -> z0, "FitType" -> "CycleOnlyConditional", "FitEpsilonMin" -> fitEpsilonRange[[1]],
               "FitEpsilonMax" -> fitEpsilonRange[[2]]|>, fitCycle,
             <|"MeanOtherPairFraction" -> Mean[(#["OtherPairFractionCycleOnly"] & /@ rows)],
               "MeanLinePairFraction" -> Mean[(#["LinePairFraction"] & /@ rows)]|>]
      }
    ],
    {z0, zSlices}
  ], 1];

  safeExport[FileNameJoin[{outDir, "fig16_threeclass_uncertainty_by_seed.csv"}],
    Prepend[(Values /@ uncertaintyRows), Keys[First[uncertaintyRows]]], "CSV"];
  safeExport[FileNameJoin[{outDir, "fig16_threeclass_uncertainty_pooled.csv"}],
    Prepend[(Values /@ uncertaintyPooled), Keys[First[uncertaintyPooled]]], "CSV"];
  safeExport[FileNameJoin[{outDir, "fig16_threeclass_uncertainty_fit_summary.csv"}],
    Prepend[(Values /@ uncertaintyFits), Keys[First[uncertaintyFits]]], "CSV"];

  Module[{panels},
    panels = Table[
      makeUncertaintyPanel[
        Select[uncertaintyPooled, #["z"] == z0 &],
        First[Select[uncertaintyFits, #["z"] == z0 && #["FitType"] == "ThreeClass" &]],
        z0
      ],
      {z0, zSlices}
    ];
    exportFigure["fig16_threeclass_uncertainty", GraphicsRow[panels, Spacings -> 18, ImageSize -> 1280]];
  ];
];

(* ------------------------------------------------------------------------- *)
(* Fig. 17: three-class entropy and resolution sweep                         *)
(* ------------------------------------------------------------------------- *)

ClearAll[classEntropy, boxEntropySummary, computeEntropyCase];

classEntropy[counts_List] := Module[{total = Total[counts], p},
  If[total <= 0, Return[0.]];
  p = Select[N[counts/total], # > 0 &];
  -Total[p Log[p]]
];

boxEntropySummary[boxCounts_List] := Module[
  {counts3, counts4, s3List, s4List, mixed3, mixed4, boundary3, boundary4,
   totals3, totals4, totalSamples, plus, minus, line, plane, other},
  counts4 = boxCounts;
  counts3 = boxCounts[[All, {1, 2, 3}]];
  s3List = classEntropy /@ counts3;
  s4List = classEntropy /@ counts4;
  mixed3 = Map[Count[#, _?(# > 0 &)] >= 2 &, counts3];
  mixed4 = Map[Count[#, _?(# > 0 &)] >= 2 &, counts4];
  boundary3 = Pick[s3List, mixed3];
  boundary4 = Pick[s4List, mixed4];
  totals3 = Total[counts3];
  totals4 = Total[counts4];
  totalSamples = Total[totals4];
  plus = totals4[[1]]; minus = totals4[[2]]; line = totals4[[3]]; plane = totals4[[4]]; other = totals4[[5]];
  <|
    "TotalSamples" -> totalSamples,
    "Plus" -> plus, "Minus" -> minus, "LineSet" -> line, "PlaneOnly" -> plane, "StillOther" -> other,
    "PlusFraction" -> N[plus/totalSamples],
    "MinusFraction" -> N[minus/totalSamples],
    "LineSetFraction" -> N[line/totalSamples],
    "PlaneOnlyFraction" -> N[plane/totalSamples],
    "StillOtherFraction" -> N[other/totalSamples],
    "S3" -> Mean[s3List],
    "S3OverLog3" -> Mean[s3List]/Log[3],
    "Sbb3" -> If[Length[boundary3] > 0, Mean[boundary3], 0.],
    "Sbb3OverLog3" -> If[Length[boundary3] > 0, Mean[boundary3]/Log[3], 0.],
    "MixedBoxFraction3" -> N[Count[mixed3, True]/Length[mixed3]],
    "S4" -> Mean[s4List],
    "S4OverLog4" -> Mean[s4List]/Log[4],
    "Sbb4" -> If[Length[boundary4] > 0, Mean[boundary4], 0.],
    "Sbb4OverLog4" -> If[Length[boundary4] > 0, Mean[boundary4]/Log[4], 0.],
    "MixedBoxFraction4" -> N[Count[mixed4, True]/Length[mixed4]]
  |>
];

computeEntropyCase[z0_?NumericQ, nBoxes_Integer, samplesPerBox_Integer, seed_Integer] := Module[
  {boxCounts, ix, iy, s, xMin, xMax, yMin, yMax, pt, lab, counts, summary},
  Print["Computing entropy case: z=", z0, ", boxes=", nBoxes, ", samples/box=", samplesPerBox, ", seed=", seed];
  boxCounts = Flatten[
    Table[
      counts = {0, 0, 0, 0, 0}; (* plus, minus, line, plane only, other *)
      xMin = (ix - 1)/nBoxes; xMax = ix/nBoxes;
      yMin = (iy - 1)/nBoxes; yMax = iy/nBoxes;
      BlockRandom[
        SeedRandom[makeSeed["fig20-threeclass", z0, nBoxes, samplesPerBox, seed, ix, iy]];
        Do[
          pt = {RandomReal[{xMin, xMax}], RandomReal[{yMin, yMax}], z0};
          lab = classifyLabel[pt];
          Switch[lab,
            1, counts[[1]]++,
            -1, counts[[2]]++,
            2, counts[[3]]++,
            3, counts[[4]]++,
            _, counts[[5]]++
          ];
          , {s, samplesPerBox}]
      ];
      counts,
      {iy, 1, nBoxes}, {ix, 1, nBoxes}
    ], 1
  ];
  summary = boxEntropySummary[boxCounts];
  Join[<|"z" -> z0, "Boxes" -> nBoxes, "SamplesPerBox" -> samplesPerBox,
         "Seed" -> seed, "NumberOfBoxes" -> nBoxes^2|>, summary]
];

entropyRows = {};

ClearAll[makeMainEntropyPlot, makeFractionPlot, makeResolutionPlot, makeResolutionPlotBySlice, groupedBarGraphic, orderedMainRows];

orderedMainRows[rows_] := Flatten[Table[Select[rows, #["z"] == z &], {z, {0.5, 0.3}}], 1];

ClearAll[groupedBarGraphic];
groupedBarGraphic[data_, groupLabels_, seriesLabels_, colors_, title_, yLabel_] := Module[
  {nGroups, nSeries, centers, barWidth, offsets, rects, xTicks, yTicks, legend},
  nGroups = Length[data];
  nSeries = Length[seriesLabels];
  centers = Range[nGroups];
  barWidth = Min[0.16, 0.55/nSeries];
  offsets = (Range[nSeries] - (nSeries + 1)/2) * (barWidth*1.35);
  rects = Flatten[
    Table[
      {EdgeForm[Directive[GrayLevel[0.25], Thin]], colors[[j]],
       Rectangle[{centers[[i]] + offsets[[j]] - barWidth/2, 0},
                 {centers[[i]] + offsets[[j]] + barWidth/2, data[[i, j]]}]},
      {i, nGroups}, {j, nSeries}
    ], 1
  ];
  xTicks = Thread[{centers, (Style[#, figTickFont, FontFamily -> figFontFamily] & /@ groupLabels)}];
  yTicks = Table[{v, Style[NumberForm[v, {2, 1}], figTickFont, FontFamily -> figFontFamily]}, {v, 0, 1, 0.2}];
  legend = SwatchLegend[colors, seriesLabels, LegendLayout -> "Row",
    LabelStyle -> {FontSize -> figLegendFont, FontFamily -> figFontFamily}];
  Legended[
    Graphics[
      rects,
      Frame -> True,
      FrameTicks -> {{yTicks, None}, {xTicks, None}},
      FrameLabel -> {{Style[yLabel, figLabelFont, FontFamily -> figFontFamily], None}, {None, None}},
      PlotRange -> {{0.45, nGroups + 0.55}, {0, 1}},
      ImagePadding -> {{90, 25}, {75, 35}},
      ImageSize -> 760,
      AspectRatio -> 0.48,
      BaseStyle -> {FontSize -> figBaseFont, FontFamily -> figFontFamily},
      PlotLabel -> Style[title, figTitleFont, Bold, FontFamily -> figFontFamily]
    ],
    Placed[legend, Above]
  ]
];

makeMainEntropyPlot[mainRows_] := Module[{rows, data, groupLabels, seriesLabels, colors},
  rows = orderedMainRows[mainRows];
  groupLabels = If[# == 0.5, "z=1/2", "z=0.3"] & /@ (#["z"] & /@ rows);
  seriesLabels = {"S3/log 3", "Sbb3/log 3", "mixed-box", "line-set fraction"};
  colors = {RGBColor[0.95, 0.62, 0.18], RGBColor[0.86, 0.35, 0.10], RGBColor[0.63, 0.34, 0.45], RGBColor[0.34, 0.44, 0.80]};
  data = Table[{r["S3OverLog3"], r["Sbb3OverLog3"], r["MixedBoxFraction3"], r["LineSetFraction"]}, {r, rows}];
  groupedBarGraphic[data, groupLabels, seriesLabels, colors, "Three-class entropy and line-set fraction", "normalized value / fraction"]
];

makeFractionPlot[mainRows_] := Module[{rows, data, groupLabels, seriesLabels, colors},
  rows = orderedMainRows[mainRows];
  groupLabels = If[# == 0.5, "z=1/2", "z=0.3"] & /@ (#["z"] & /@ rows);
  seriesLabels = {"P-cycle", "P'-cycle", "line set L", "other"};
  colors = {Black, GrayLevel[0.55], RGBColor[0.1, 0.32, 0.85], RGBColor[0.85, 0.1, 0.1]};
  data = Table[{r["PlusFraction"], r["MinusFraction"], r["LineSetFraction"], r["PlaneOnlyFraction"] + r["StillOtherFraction"]}, {r, rows}];
  groupedBarGraphic[data, groupLabels, seriesLabels, colors, "Class fractions", "class fraction"]
];

makeResolutionPlotBySlice[rows_, z0_] := Module[{metrics, panels, sub, colors, labels, legend, zText},
  metrics = {
    {"S3OverLog3", "S3/log 3"},
    {"Sbb3OverLog3", "Sbb3/log 3"},
    {"MixedBoxFraction3", "mixed-box fraction"},
    {"LineSetFraction", "line-set fraction"}
  };
  colors = Take[{RGBColor[0.15, 0.35, 0.70], RGBColor[0.92, 0.55, 0.12], RGBColor[0.15, 0.55, 0.25], RGBColor[0.60, 0.25, 0.65]}, Length[entropySamplesPerBoxList]];
  labels = ("m=" <> ToString[#] & /@ entropySamplesPerBoxList);
  zText = If[z0 == 0.5, "z=1/2", "z=0.3"];
  panels = Table[
    ListLinePlot[
      Table[
        sub = SortBy[Select[rows, #["z"] == z0 && #["SamplesPerBox"] == spb &], #["Boxes"] &];
        ({#["Boxes"], #[metric[[1]]]} & /@ sub),
        {spb, entropySamplesPerBoxList}
      ],
      PlotMarkers -> Automatic,
      PlotStyle -> colors,
      PlotRange -> {0, 1},
      Frame -> True,
      FrameLabel -> {{Style[metric[[2]], 15, FontFamily -> figFontFamily], None},
                     {Style["boxes per axis", 15, FontFamily -> figFontFamily], None}},
      PlotLabel -> Style[metric[[2]], 16, FontFamily -> figFontFamily],
      ImageSize -> 330,
      ImagePadding -> {{65, 18}, {55, 35}},
      BaseStyle -> {FontSize -> 13, FontFamily -> figFontFamily},
      GridLines -> Automatic,
      GridLinesStyle -> Directive[GrayLevel[0.88], Thin]
    ],
    {metric, metrics}
  ];
  legend = LineLegend[colors, labels, LegendLayout -> "Row", LabelStyle -> {FontSize -> 15, FontFamily -> figFontFamily}];
  Legended[
    Labeled[
      GraphicsGrid[Partition[panels, 2], Spacings -> {0.10, 0.20}, ImageSize -> 720],
      Style[zText <> ": resolution and sampling dependence", figTitleFont, Bold, FontFamily -> figFontFamily],
      Top
    ],
    Placed[legend, Above]
  ]
];

makeResolutionPlot[rows_] := GraphicsRow[
  {makeResolutionPlotBySlice[rows, 0.5], makeResolutionPlotBySlice[rows, 0.3]},
  Spacings -> 6,
  ImageSize -> 1500
];

If[runFig17,
  Print["Computing Fig. 17 three-class entropy data..."];
  entropyRows = Flatten[
    Table[
      computeEntropyCase[z0, nBoxes, samplesPerBox, seed],
      {z0, zSlices}, {nBoxes, entropyBoxesList}, {samplesPerBox, entropySamplesPerBoxList}, {seed, entropySeeds}
    ], 3
  ];
  safeExport[FileNameJoin[{outDir, "fig17_threeclass_entropy_summary.csv"}],
    Prepend[(Values /@ entropyRows), Keys[First[entropyRows]]], "CSV"];

  Module[{mainRows},
    mainRows = SortBy[
      Select[entropyRows, #["Boxes"] == entropyMainBoxes && #["SamplesPerBox"] == entropyMainSamplesPerBox &],
      #["z"] &
    ];
    safeExport[FileNameJoin[{outDir, "fig17_threeclass_main_values.csv"}],
      Prepend[(Values /@ mainRows), Keys[First[mainRows]]], "CSV"];
    exportFigure["fig17_threeclass_entropy_main", makeMainEntropyPlot[mainRows]];
    exportFigure["fig17_threeclass_class_fractions", makeFractionPlot[mainRows]];
    exportFigure["fig17_threeclass_entropy_resolution_sweep", makeResolutionPlot[entropyRows]];
    exportFigure["fig17_threeclass_entropy_resolution_sweep_z0p5", makeResolutionPlotBySlice[entropyRows, 0.5]];
    exportFigure["fig17_threeclass_entropy_resolution_sweep_z0p3", makeResolutionPlotBySlice[entropyRows, 0.3]];
  ];
];

(* ------------------------------------------------------------------------- *)
(* Final report                                                              *)
(* ------------------------------------------------------------------------- *)

Print["Done. Output directory: ", outDir];
Print["Suggested manuscript interpretation: use three classes B+, B-, and L."];
Print["If StillOtherFraction is zero or negligible, avoid calling L points 'unclassified'."];

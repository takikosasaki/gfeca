(* Rule 210 interval verification for the three-cell GFDNF *)
ClearAll["Global`*"];

(* Exact intervals *)
Ia = Interval[{47853509437/100000000000, 47853509439/100000000000}];

pa[t_] := 94770 t^3 - 211653 t^2 + 149499 t - 33458;

bfun[t_] := (11664/281) t^3 - (123228/1405) t^2 + (1048793/18265) t - 206733/18265;
cfun[t_] := -(4860/281) t^3 + (10269/281) t^2 - (177843/7306) t + 39935/7306;
dfun[t_] := -(12636/281) t^3 + (133497/1405) t^2 - (177843/2810) t + 39373/2810;

Print["p_a endpoints: ", N[pa[Ia[[1,1]]],20], "  ", N[pa[Ia[[1,2]]],20]];
Print["p_a' on Ia: ", N[pa'[Ia],20]];

Ib = bfun[Ia];
Ic = cfun[Ia];
Id = dfun[Ia];

Print["Ia = ", N[Ia,20]];
Print["Ib = ", N[Ib,20]];
Print["Ic = ", N[Ic,20]];
Print["Id = ", N[Id,20]];

(* Check Groebner basis for the algebraic system *)
a =.; b =.; c =.; d =.;
F = {
 c - (9 a b - (9/2) a - 6 b + 7/2),
 d - (-9 a b + 3 a + (9/2) b - 1),
 b - (-9 c d + 6 c + (3/2) d - 1/2),
 a - (9 c d - (9/2) c - 3 d + 2)
};
G = GroebnerBasis[F, {b,c,d,a}];
Print["Groebner basis = ", G];

(* Interval monodromy matrix *)
ai = Ia; bi = Ib; ci = Ic; di = Id;

J0[aa_,bb_,cc_,dd_] := {
 {9 bb - 9/2, -54 aa bb + 27 aa + 18 bb - 9, 9 aa - 6},
 {3 - 9 bb, -54 aa bb + 36 aa + 27 bb - 18, 9/2 - 9 aa},
 {0, -54 aa bb + 18 aa + 36 bb - 15, 0}
};

J1[aa_,bb_,cc_,dd_] := {
 {0, 0, 54 cc dd - 36 cc - 18 dd + 9},
 {6 - 9 dd, 3/2 - 9 cc, 54 cc dd - 18 cc - 9 dd + 3},
 {9 dd - 9/2, 9 cc - 3, 27 cc (2 dd - 1)}
};

J2[aa_,bb_,cc_,dd_] := {
 {-54 aa bb + 36 aa + 27 bb - 18, 9/2 - 9 aa, 3 - 9 bb},
 {-54 aa bb + 18 aa + 36 bb - 15, 0, 0},
 {-54 aa bb + 27 aa + 18 bb - 9, 9 aa - 6, 9 bb - 9/2}
};

J3[aa_,bb_,cc_,dd_] := {
 {3/2 - 9 cc, 54 cc dd - 18 cc - 9 dd + 3, 6 - 9 dd},
 {9 cc - 3, 27 cc (2 dd - 1), 9 dd - 9/2},
 {0, 54 cc dd - 36 cc - 18 dd + 9, 0}
};

J4[aa_,bb_,cc_,dd_] := {
 {0, 0, -54 aa bb + 18 aa + 36 bb - 15},
 {9 aa - 6, 9 bb - 9/2, -54 aa bb + 27 aa + 18 bb - 9},
 {9/2 - 9 aa, 3 - 9 bb, -54 aa bb + 36 aa + 27 bb - 18}
};

J5[aa_,bb_,cc_,dd_] := {
 {27 cc (2 dd - 1), 9 dd - 9/2, 9 cc - 3},
 {54 cc dd - 36 cc - 18 dd + 9, 0, 0},
 {54 cc dd - 18 cc - 9 dd + 3, 6 - 9 dd, 3/2 - 9 cc}
};

M = J5[ai,bi,ci,di].J4[ai,bi,ci,di].J3[ai,bi,ci,di].J2[ai,bi,ci,di].J1[ai,bi,ci,di].J0[ai,bi,ci,di];

Aint = -Tr[M];
Bint = M[[1,1]] M[[2,2]] - M[[1,2]] M[[2,1]]
     + M[[1,1]] M[[3,3]] - M[[1,3]] M[[3,1]]
     + M[[2,2]] M[[3,3]] - M[[2,3]] M[[3,2]];
Cint = -Det[M];

Jury1 = 1 + Aint + Bint + Cint;
Jury2 = 1 - Aint + Bint - Cint;
Jury3 = 1 - Bint + Aint Cint - Cint^2;

Print["A interval = ", N[Aint,20]];
Print["B interval = ", N[Bint,20]];
Print["C interval = ", N[Cint,20]];
Print["Jury 1+A+B+C = ", N[Jury1,20]];
Print["Jury 1-A+B-C = ", N[Jury2,20]];
Print["Jury 1-B+A C-C^2 = ", N[Jury3,20]];
Print["Abs C upper < 1?  ", Max[Abs /@ Cint[[1]]] < 1];

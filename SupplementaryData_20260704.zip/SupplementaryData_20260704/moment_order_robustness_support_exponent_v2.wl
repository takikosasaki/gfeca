(* ::Package:: *)
(* Moment-order robustness check for the effective support exponent s^(p).
   This script recomputes the support exponent for p = 8,16,32,64
   under the numerical protocols used for the manuscript Section 5.

   It exports CSV data and supplementary figures:
     - q_a deformation: rules 30, 90, 184
     - gap function r_a: rules 102, 184
     - convex mixing of rules 184 and 90

   Safe default output directory is outside OneDrive:
     Windows: C:/GFECA_results/support_moment_order_robustness_<timestamp>
     Other:   $HomeDirectory/GFECA_results/support_moment_order_robustness_<timestamp>

   Usage in a notebook:
     quickTest = True;  (* first run, optional *)
     Get["C:/Users/toki/Downloads/moment_order_robustness_support_exponent_v2.wl"]

     quickTest = False; (* full run *)
     Get["C:/Users/toki/Downloads/moment_order_robustness_support_exponent_v2.wl"]

   Optional before Get:
     outputRootOverride = "C:/GFECA_results";
     runQaExperiment = True; runGapExperiment = True; runMixingExperiment = True;
*)

ClearAll[ensureValue];
SetAttributes[ensureValue, HoldFirst];
ensureValue[sym_Symbol, val_] := If[! ValueQ[sym], sym = val];

ensureValue[quickTest, False];
ensureValue[runQaExperiment, True];
ensureValue[runGapExperiment, True];
ensureValue[runMixingExperiment, True];
ensureValue[exportRawCsv, True];
ensureValue[exportPng, True];
ensureValue[exportPdf, True];

If[$OperatingSystem === "Windows",
  ensureValue[outputRootOverride, "C:/GFECA_results"],
  ensureValue[outputRootOverride, FileNameJoin[{$HomeDirectory, "GFECA_results"}]]
];

(* ---------- Numerical configuration ---------- *)
seed = 20260316;
epsRound = 10^-12;
energyFloor = 10^-300;
pList = {8, 16, 32, 64};

If[TrueQ[quickTest],
  qaRules = {30, 90, 184};
  qaSites = 60; qaFinalTime = 60; qaWindowStart = 30;
  qaSamples = 5;
  qaParameterGrid = N[Range[0, 1, 0.1]];

  gapRules = {102, 184};
  gapSites = 40; gapFinalTime = 80; gapWindowStart = 40;
  gapSamples = 5;
  gapParameterGrid = N[Range[1, 2, 0.1]];

  mixSites = 50; mixFinalTime = 120; mixWindowStart = 90;
  mixParameterGrid = N[Range[0, 1, 0.025]];
  ,
  qaRules = {30, 90, 184};
  qaSites = 100; qaFinalTime = 100; qaWindowStart = 50;
  qaSamples = 50;
  qaParameterGrid = N[Range[0, 1, 0.01]];

  gapRules = {102, 184};
  gapSites = 50; gapFinalTime = 200; gapWindowStart = 100;
  gapSamples = 30;
  gapParameterGrid = N[Range[1, 2, 0.01]];

  mixSites = 50; mixFinalTime = 500; mixWindowStart = 450;
  mixParameterGrid = N[Range[0, 1, 0.005]];
];

runStamp = DateString[{"Year", "Month", "Day", "_", "Hour", "Minute", "Second"}];
outDir = FileNameJoin[{outputRootOverride, "support_moment_order_robustness_" <> runStamp}];
If[! DirectoryQ[outDir], CreateDirectory[outDir, CreateIntermediateDirectories -> True]];
figDir = FileNameJoin[{outDir, "figures"}];
If[! DirectoryQ[figDir], CreateDirectory[figDir, CreateIntermediateDirectories -> True]];

Print["Output directory: ", outDir];

(* ---------- Safe export ---------- *)
ClearAll[safeExport];
safeExport[file_String, expr_, fmt_:Automatic] := Module[{dir, ext, tmp, ok},
  dir = DirectoryName[file];
  ext = FileExtension[file];
  If[! DirectoryQ[dir], CreateDirectory[dir, CreateIntermediateDirectories -> True]];
  tmp = FileNameJoin[{dir, CreateUUID["tmp-"] <> If[ext === "", "", "." <> ext]}];
  ok = Quiet@Check[
      If[fmt === Automatic, Export[tmp, expr], Export[tmp, expr, fmt]];
      If[FileExistsQ[file], DeleteFile[file]];
      RenameFile[tmp, file];
      True,
      False
    ];
  If[FileExistsQ[tmp], Quiet[DeleteFile[tmp]]];
  If[TrueQ[ok], Print["Exported: ", file], Print["Export failed: ", file]];
  ok
];

(* ---------- ECA and update maps ---------- *)
ClearAll[bitsForRule];
bitsForRule[rule_Integer] := N[Table[BitGet[rule, i], {i, 0, 7}]];

compiledStepQa = Compile[
  {{state, _Real, 1}, {a, _Real}, {bits, _Real, 1}, {eps, _Real}},
  Module[{n, new, j, leftIndex, rightIndex, xl, xc, xr, ql, qc, qr, v,
    denom, lowerBreak, upperBreak, b0, b1, b2, b3, b4, b5, b6, b7},
   n = Length[state];
   new = Table[0., {Length[state]}];
   denom = 3. - a;
   lowerBreak = 1./denom;
   upperBreak = (2. - a)/denom;
   b0 = bits[[1]]; b1 = bits[[2]]; b2 = bits[[3]]; b3 = bits[[4]];
   b4 = bits[[5]]; b5 = bits[[6]]; b6 = bits[[7]]; b7 = bits[[8]];
   For[j = 1, j <= n, j++,
    leftIndex = If[j == 1, n, j - 1];
    rightIndex = If[j == n, 1, j + 1];
    xl = state[[leftIndex]]; xc = state[[j]]; xr = state[[rightIndex]];

    ql = If[xl <= lowerBreak, a*xl, If[xl <= upperBreak, 3.*xl - 1., a*xl + 1. - a]];
    qc = If[xc <= lowerBreak, a*xc, If[xc <= upperBreak, 3.*xc - 1., a*xc + 1. - a]];
    qr = If[xr <= lowerBreak, a*xr, If[xr <= upperBreak, 3.*xr - 1., a*xr + 1. - a]];

    v = b0*(1. - ql)*(1. - qc)*(1. - qr) +
        b1*(1. - ql)*(1. - qc)*qr +
        b2*(1. - ql)*qc*(1. - qr) +
        b3*(1. - ql)*qc*qr +
        b4*ql*(1. - qc)*(1. - qr) +
        b5*ql*(1. - qc)*qr +
        b6*ql*qc*(1. - qr) +
        b7*ql*qc*qr;

    If[v < eps, v = 0., If[v > 1. - eps, v = 1.]];
    If[v < 0., v = 0., If[v > 1., v = 1.]];
    new[[j]] = v;
    ];
   new
   ],
  RuntimeOptions -> "Speed"
];

compiledStepGap = Compile[
  {{state, _Real, 1}, {a, _Real}, {bits, _Real, 1}, {eps, _Real}},
  Module[{n, new, j, leftIndex, rightIndex, xl, xc, xr, ql, qc, qr, v, out,
    b0, b1, b2, b3, b4, b5, b6, b7},
   n = Length[state];
   new = Table[0., {Length[state]}];
   b0 = bits[[1]]; b1 = bits[[2]]; b2 = bits[[3]]; b3 = bits[[4]];
   b4 = bits[[5]]; b5 = bits[[6]]; b6 = bits[[7]]; b7 = bits[[8]];
   For[j = 1, j <= n, j++,
    leftIndex = If[j == 1, n, j - 1];
    rightIndex = If[j == n, 1, j + 1];
    xl = state[[leftIndex]]; xc = state[[j]]; xr = state[[rightIndex]];

    ql = If[xl <= 0.5, a*xl, a*xl - a + 1.];
    qc = If[xc <= 0.5, a*xc, a*xc - a + 1.];
    qr = If[xr <= 0.5, a*xr, a*xr - a + 1.];

    v = b0*(1. - ql)*(1. - qc)*(1. - qr) +
        b1*(1. - ql)*(1. - qc)*qr +
        b2*(1. - ql)*qc*(1. - qr) +
        b3*(1. - ql)*qc*qr +
        b4*ql*(1. - qc)*(1. - qr) +
        b5*ql*(1. - qc)*qr +
        b6*ql*qc*(1. - qr) +
        b7*ql*qc*qr;

    out = If[v <= 0.5, a*v, a*v - a + 1.];
    If[out < eps, out = 0., If[out > 1. - eps, out = 1.]];
    If[out < 0., out = 0., If[out > 1., out = 1.]];
    new[[j]] = out;
    ];
   new
   ],
  RuntimeOptions -> "Speed"
];

compiledStepMix18490 = Compile[
  {{state, _Real, 1}, {alpha, _Real}, {bits184, _Real, 1}, {bits90, _Real, 1}, {eps, _Real}},
  Module[{n, new, j, leftIndex, rightIndex, xl, xc, xr, ql, qc, qr,
    v184, v90, out, c0, c1, c2, c3, c4, c5, c6, c7, d0, d1, d2, d3, d4, d5, d6, d7},
   n = Length[state];
   new = Table[0., {Length[state]}];
   c0 = bits184[[1]]; c1 = bits184[[2]]; c2 = bits184[[3]]; c3 = bits184[[4]];
   c4 = bits184[[5]]; c5 = bits184[[6]]; c6 = bits184[[7]]; c7 = bits184[[8]];
   d0 = bits90[[1]]; d1 = bits90[[2]]; d2 = bits90[[3]]; d3 = bits90[[4]];
   d4 = bits90[[5]]; d5 = bits90[[6]]; d6 = bits90[[7]]; d7 = bits90[[8]];
   For[j = 1, j <= n, j++,
    leftIndex = If[j == 1, n, j - 1];
    rightIndex = If[j == n, 1, j + 1];
    xl = state[[leftIndex]]; xc = state[[j]]; xr = state[[rightIndex]];

    (* q0, i.e. q_a with a = 0 *)
    ql = If[xl <= 1./3., 0., If[xl <= 2./3., 3.*xl - 1., 1.]];
    qc = If[xc <= 1./3., 0., If[xc <= 2./3., 3.*xc - 1., 1.]];
    qr = If[xr <= 1./3., 0., If[xr <= 2./3., 3.*xr - 1., 1.]];

    v184 = c0*(1. - ql)*(1. - qc)*(1. - qr) +
        c1*(1. - ql)*(1. - qc)*qr +
        c2*(1. - ql)*qc*(1. - qr) +
        c3*(1. - ql)*qc*qr +
        c4*ql*(1. - qc)*(1. - qr) +
        c5*ql*(1. - qc)*qr +
        c6*ql*qc*(1. - qr) +
        c7*ql*qc*qr;

    v90 = d0*(1. - ql)*(1. - qc)*(1. - qr) +
        d1*(1. - ql)*(1. - qc)*qr +
        d2*(1. - ql)*qc*(1. - qr) +
        d3*(1. - ql)*qc*qr +
        d4*ql*(1. - qc)*(1. - qr) +
        d5*ql*(1. - qc)*qr +
        d6*ql*qc*(1. - qr) +
        d7*ql*qc*qr;

    out = (1. - alpha)*v184 + alpha*v90;
    If[out < eps, out = 0., If[out > 1. - eps, out = 1.]];
    If[out < 0., out = 0., If[out > 1., out = 1.]];
    new[[j]] = out;
    ];
   new
   ],
  RuntimeOptions -> "Speed"
];

(* ---------- Evolution and support exponent ---------- *)
ClearAll[evolveWindow];
evolveWindow[initialState_, finalTime_Integer, windowStart_Integer, stepFunction_] := Module[
  {state, window, t},
  state = N[initialState];
  window = {};
  If[0 >= windowStart, window = {state}];
  For[t = 1, t <= finalTime, t++,
   state = stepFunction[state];
   If[t >= windowStart, window = Append[window, state]];
   ];
  window
];

ClearAll[supportValues];
supportValues[window_List, fieldMode_String, pVals_List, eps_] := Module[
  {vals, phi, m, s2, energy, weights, total, sVal},
  vals = N[Flatten[window]];
  phi = If[fieldMode === "Deviation", Abs[vals - Mean[vals]], Abs[vals]];
  phi = Map[If[# < eps, 0., #] &, phi];
  m = Length[phi];
  s2 = Total[phi^2];
  energy = s2/m;
  If[s2 <= 0.,
   Table[{p, 0., energy}, {p, pVals}],
   weights = phi^2/s2;
   Table[
    total = Total[weights^p];
    sVal = If[total <= 0., 0., -(2./(p - 1.))*Log[total]/Log[m]];
    {p, sVal, energy},
    {p, pVals}
    ]
   ]
];

ClearAll[meanOrZero, sdOrZero];
meanOrZero[v_List] := If[Length[v] == 0, Missing["NoData"], Mean[v]];
sdOrZero[v_List] := If[Length[v] <= 1, 0., StandardDeviation[v]];

ClearAll[summarizeRows];
summarizeRows[rawRows_List] := Module[{groups},
  groups = GatherBy[rawRows, #[[{1, 2, 3, 4, 6}]] &];
  SortBy[
   Table[
    With[{g = groups[[i]], sVals = groups[[i]][[All, 7]], eVals = groups[[i]][[All, 8]]},
     {g[[1, 1]], g[[1, 2]], g[[1, 3]], g[[1, 4]], g[[1, 6]], Length[g],
      meanOrZero[sVals], sdOrZero[sVals], meanOrZero[eVals], sdOrZero[eVals]}
     ],
    {i, Length[groups]}
    ],
   {#[[1]], #[[2]], #[[4]], #[[5]]} &
   ]
];

(* ---------- Run experiments ---------- *)
rawRows = {};

If[TrueQ[runQaExperiment],
  Print["Running q_a moment-order robustness experiment..."];
  SeedRandom[seed];
  qaInitialConditions = N[Table[RandomReal[{0, 1}, qaSites], {qaSamples}]];
  Do[
   bits = bitsForRule[rule];
   Print["  q_a rule ", rule];
   Do[
    If[Mod[Round[100*a], 20] == 0, Print["    a = ", NumberForm[a, {3, 2}]]];
    Do[
     window = evolveWindow[
       qaInitialConditions[[sampleIndex]], qaFinalTime, qaWindowStart,
       Function[st, compiledStepQa[st, a, bits, epsRound]]
       ];
     vals = supportValues[window, "Deviation", pList, epsRound];
     rawRows = Join[rawRows,
       ({"qa", ToString[rule], "a", N[a], sampleIndex, #[[1]], #[[2]], #[[3]]} & /@ vals)
       ];
     , {sampleIndex, qaSamples}]
    , {a, qaParameterGrid}]
   , {rule, qaRules}];
];

If[TrueQ[runGapExperiment],
  Print["Running gap r_a moment-order robustness experiment..."];
  SeedRandom[seed];
  gapInitialConditions = N[Table[RandomReal[{0, 1}, gapSites], {gapSamples}]];
  Do[
   bits = bitsForRule[rule];
   Print["  gap rule ", rule];
   Do[
    If[Mod[Round[100*(a - 1)], 20] == 0, Print["    a = ", NumberForm[a, {3, 2}]]];
    Do[
     window = evolveWindow[
       gapInitialConditions[[sampleIndex]], gapFinalTime, gapWindowStart,
       Function[st, compiledStepGap[st, a, bits, epsRound]]
       ];
     vals = supportValues[window, "Deviation", pList, epsRound];
     rawRows = Join[rawRows,
       ({"gap", ToString[rule], "a", N[a], sampleIndex, #[[1]], #[[2]], #[[3]]} & /@ vals)
       ];
     , {sampleIndex, gapSamples}]
    , {a, gapParameterGrid}]
   , {rule, gapRules}];
];

If[TrueQ[runMixingExperiment],
  Print["Running convex mixing moment-order robustness experiment..."];
  bits184 = bitsForRule[184];
  bits90 = bitsForRule[90];
  mixInitial = ConstantArray[0., mixSites];
  mixInitial[[1]] = 0.6;
  Do[
   If[Mod[Round[1000*alpha], 100] == 0, Print["  alpha = ", NumberForm[alpha, {3, 3}]]];
   window = evolveWindow[
     mixInitial, mixFinalTime, mixWindowStart,
     Function[st, compiledStepMix18490[st, alpha, bits184, bits90, epsRound]]
     ];
   vals = supportValues[window, "State", pList, epsRound];
   rawRows = Join[rawRows,
     ({"mix18490", "184-90", "alpha", N[alpha], 1, #[[1]], #[[2]], #[[3]]} & /@ vals)
     ];
   , {alpha, mixParameterGrid}];
];

summaryRows = summarizeRows[rawRows];

(* ---------- Export data ---------- *)
metadata = <|
   "Description" -> "Moment-order robustness check for effective support exponent s^(p)",
   "QuickTest" -> quickTest,
   "Seed" -> seed,
   "MomentOrders" -> pList,
   "RoundingThreshold" -> epsRound,
   "Qa" -> <|"Rules" -> qaRules, "N" -> qaSites, "T" -> qaFinalTime,
     "WindowStart" -> qaWindowStart, "Samples" -> qaSamples,
     "ParameterGrid" -> {Min[qaParameterGrid], Max[qaParameterGrid], "step", If[Length[qaParameterGrid] > 1, qaParameterGrid[[2]] - qaParameterGrid[[1]], Missing[]]},
     "Field" -> "deviation from spacetime mean"|>,
   "Gap" -> <|"Rules" -> gapRules, "N" -> gapSites, "T" -> gapFinalTime,
     "WindowStart" -> gapWindowStart, "Samples" -> gapSamples,
     "ParameterGrid" -> {Min[gapParameterGrid], Max[gapParameterGrid], "step", If[Length[gapParameterGrid] > 1, gapParameterGrid[[2]] - gapParameterGrid[[1]], Missing[]]},
     "Field" -> "deviation from spacetime mean"|>,
   "Mixing" -> <|"Rules" -> "184 and 90", "N" -> mixSites, "T" -> mixFinalTime,
     "WindowStart" -> mixWindowStart, "Samples" -> 1,
     "ParameterGrid" -> {Min[mixParameterGrid], Max[mixParameterGrid], "step", If[Length[mixParameterGrid] > 1, mixParameterGrid[[2]] - mixParameterGrid[[1]], Missing[]]},
     "Field" -> "state x_j^t", "InitialCondition" -> "x_0=0.6, all other cells 0"|>,
   "WolframVersion" -> $Version,
   "Date" -> DateString["ISODateTime"]
   |>;

safeExport[FileNameJoin[{outDir, "metadata.json"}], metadata, "JSON"];
safeExport[FileNameJoin[{outDir, "support_moment_order_summary.csv"}],
  Prepend[summaryRows, {"experiment", "rule", "parameterName", "parameter", "p", "sampleCount", "meanS", "sdS", "meanS2OverM", "sdS2OverM"}],
  "CSV"];

If[TrueQ[exportRawCsv],
  safeExport[FileNameJoin[{outDir, "support_moment_order_raw.csv"}],
   Prepend[rawRows, {"experiment", "rule", "parameterName", "parameter", "sampleIndex", "p", "s", "S2OverM"}],
   "CSV"];
];

If[ValueQ[qaInitialConditions],
  safeExport[FileNameJoin[{outDir, "qa_initial_conditions.csv"}],
   Prepend[MapIndexed[Join[{First[#2]}, #1] &, qaInitialConditions], Join[{"sampleIndex"}, Table["x" <> ToString[j], {j, 0, qaSites - 1}]]], "CSV"];
];
If[ValueQ[gapInitialConditions],
  safeExport[FileNameJoin[{outDir, "gap_initial_conditions.csv"}],
   Prepend[MapIndexed[Join[{First[#2]}, #1] &, gapInitialConditions], Join[{"sampleIndex"}, Table["x" <> ToString[j], {j, 0, gapSites - 1}]]], "CSV"];
];

(* ---------- Plotting ---------- *)
figFont = "Arial";
baseFontSize = 16;
labelFontSize = 18;
titleFontSize = 18;
legendFontSize = 14;
colors = ColorData[97] /@ Range[Length[pList]];

ClearAll[summarySelect, curveData, energyData];
summarySelect[exp_, rule_, p_] := SortBy[Select[summaryRows, #[[1]] == exp && #[[2]] == ToString[rule] && #[[5]] == p &], #[[4]] &];
curveData[exp_, rule_, p_] := summarySelect[exp, rule, p][[All, {4, 7}]];
energyData[exp_, rule_] := Module[{rows},
  rows = SortBy[Select[summaryRows, #[[1]] == exp && #[[2]] == ToString[rule] && #[[5]] == First[pList] &], #[[4]] &];
  rows[[All, {4, 9}]]
];

ClearAll[makeMomentPanel];
makeMomentPanel[exp_, rule_, title_, xlab_] := Module[{curves},
  curves = Table[curveData[exp, rule, p], {p, pList}];
  ListLinePlot[curves,
   Frame -> True,
   PlotRange -> {{Automatic, Automatic}, {0, 2}},
   PlotStyle -> (Directive[#, AbsoluteThickness[2.2]] & /@ colors),
   FrameLabel -> {Style[xlab, labelFontSize, FontFamily -> figFont],
     Style["support exponent  s^(p)", labelFontSize, FontFamily -> figFont]},
   PlotLabel -> Style[title, titleFontSize, Bold, FontFamily -> figFont],
   GridLines -> Automatic,
   GridLinesStyle -> Directive[GrayLevel[0.88], AbsoluteThickness[0.6]],
   ImageSize -> 420,
   BaseStyle -> {FontFamily -> figFont, FontSize -> baseFontSize},
   PlotLegends -> Placed[LineLegend[colors, ("p=" <> ToString[#] & /@ pList),
      LegendFunction -> "Frame", LabelStyle -> {FontFamily -> figFont, FontSize -> legendFontSize}], Right]
   ]
];

ClearAll[makeEnergyPanel];
makeEnergyPanel[exp_, rule_, title_, xlab_] := Module[{data, logData},
  data = energyData[exp, rule];
  logData = ({#[[1]], Log10[Max[#[[2]], energyFloor]]} & /@ data);
  ListLinePlot[logData,
   Frame -> True,
   PlotStyle -> Directive[Black, AbsoluteThickness[2.2]],
   FrameLabel -> {Style[xlab, labelFontSize, FontFamily -> figFont],
     Style["log10(S2/M)", labelFontSize, FontFamily -> figFont]},
   PlotLabel -> Style[title, titleFontSize, Bold, FontFamily -> figFont],
   GridLines -> Automatic,
   GridLinesStyle -> Directive[GrayLevel[0.88], AbsoluteThickness[0.6]],
   ImageSize -> 420,
   BaseStyle -> {FontFamily -> figFont, FontSize -> baseFontSize}
   ]
];

ClearAll[exportFigure];
exportFigure[name_, graphic_] := Module[{pdf, png},
  pdf = FileNameJoin[{figDir, name <> ".pdf"}];
  png = FileNameJoin[{figDir, name <> ".png"}];
  If[TrueQ[exportPdf], safeExport[pdf, graphic, "PDF"]];
  If[TrueQ[exportPng], safeExport[png, Rasterize[graphic, ImageResolution -> 300], "PNG"]];
];

If[TrueQ[runQaExperiment],
  qaMomentFigure = GraphicsGrid[
    {makeMomentPanel["qa", #, "rule " <> ToString[#], "a"] & /@ qaRules},
    Spacings -> {0.5, 0.5}, ImageSize -> 1500
    ];
  exportFigure["figS_moment_order_qa", qaMomentFigure];

  qaEnergyFigure = GraphicsGrid[
    {makeEnergyPanel["qa", #, "rule " <> ToString[#], "a"] & /@ qaRules},
    Spacings -> {0.5, 0.5}, ImageSize -> 1500
    ];
  exportFigure["figS_energy_qa", qaEnergyFigure];
];

If[TrueQ[runGapExperiment],
  gapMomentFigure = GraphicsGrid[
    {makeMomentPanel["gap", #, "rule " <> ToString[#], "a"] & /@ gapRules},
    Spacings -> {0.5, 0.5}, ImageSize -> 1050
    ];
  exportFigure["figS_moment_order_gap", gapMomentFigure];

  gapEnergyFigure = GraphicsGrid[
    {makeEnergyPanel["gap", #, "rule " <> ToString[#], "a"] & /@ gapRules},
    Spacings -> {0.5, 0.5}, ImageSize -> 1050
    ];
  exportFigure["figS_energy_gap", gapEnergyFigure];
];

If[TrueQ[runMixingExperiment],
  mixMomentFigure = makeMomentPanel["mix18490", "184-90", "convex mixture 184/90", "alpha"];
  exportFigure["figS_moment_order_mixing", mixMomentFigure];

  mixEnergyFigure = makeEnergyPanel["mix18490", "184-90", "convex mixture 184/90", "alpha"];
  exportFigure["figS_energy_mixing", mixEnergyFigure];
];

Print["Finished. Output directory: ", outDir];

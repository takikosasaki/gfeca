(* ::Package:: *)

(*
  rule210_make_submission_figures.wl

  Purpose:
    Redraw submission-ready Figures 14--17 for the three-class Rule 210
    classification using the CSV/WXF files produced by
    rule210_fig14_17_threeclass_revised_v3.wl.

  Usage in Mathematica notebook:

    resultDir = "C:/Users/toki/GFECA_results/rule210_fig14_17_threeclass_20260621_065654";
    Get["C:/Users/toki/Downloads/rule210_make_submission_figures.wl"]

  Usage from command line:

    wolframscript -file rule210_make_submission_figures.wl \
      "C:/Users/toki/GFECA_results/rule210_fig14_17_threeclass_20260621_065654"

  Outputs are written to resultDir/submission_figures/.

  The script does not recompute orbits. It only reads:
    fig14_15_labels_z0p5.wxf
    fig14_15_labels_z0p3.wxf
    fig16_threeclass_uncertainty_pooled.csv
    fig16_threeclass_uncertainty_fit_summary.csv
    fig17_threeclass_main_values.csv
    fig17_threeclass_entropy_summary.csv
*)

(* ---------------------------------------------------------------------- *)
(* User-adjustable options                                                 *)
(* ---------------------------------------------------------------------- *)

If[!ValueQ[submissionFigureImageResolution], submissionFigureImageResolution = 600];
If[!ValueQ[submissionExportRasterPDF], submissionExportRasterPDF = True];
If[!ValueQ[submissionFigOutDirName], submissionFigOutDirName = "submission_figures"]; 

If[!ValueQ[figFontFamily], figFontFamily = "Arial"];
If[!ValueQ[figBaseFont], figBaseFont = 20];
If[!ValueQ[figTickFont], figTickFont = 18];
If[!ValueQ[figLabelFont], figLabelFont = 22];
If[!ValueQ[figTitleFont], figTitleFont = 23];
If[!ValueQ[figLegendFont], figLegendFont = 19];
If[!ValueQ[figAnnotationFont], figAnnotationFont = 17];

(* z order is made consistent across Figs. 14--17. *)
If[!ValueQ[zOrderForSubmission], zOrderForSubmission = {0.5, 0.3}];

(* For journal submission, figure numbers are normally supplied by LaTeX captions.
   Set this True only for standalone internal figures. *)
If[!ValueQ[includeFigureNumberInPlotTitle], includeFigureNumberInPlotTitle = False];

(* Put panel labels inside the graphics instead of outside the bounding box. *)
If[!ValueQ[includePanelLabelsInFig17], includePanelLabelsInFig17 = True];
If[!ValueQ[exportCombinedFig14and15], exportCombinedFig14and15 = False];

(* Class colors.  These are intentionally identical across Figs. 14--17. *)
classColorRules = {
  1 -> Black,
  -1 -> GrayLevel[0.63],
  2 -> RGBColor[0.10, 0.32, 0.85],
  3 -> RGBColor[0.85, 0.10, 0.10],
  0 -> RGBColor[0.85, 0.10, 0.10]
};
classColors = {Black, GrayLevel[0.63], RGBColor[0.10, 0.32, 0.85], RGBColor[0.85, 0.10, 0.10]};
classLabels = {Row[{Style["P", Italic], "-cycle"}], Row[{Style["P'", Italic], "-cycle"}], Row[{"line set ", Style["L", Italic]}], "other"};

(* Metric colors for Fig. 17(b).  The line-set fraction uses the same blue as L. *)
metricColors = {GrayLevel[0.05], GrayLevel[0.42], GrayLevel[0.72], RGBColor[0.10, 0.32, 0.85]};
metricLabels = {Row[{Subscript[Style["S", Italic], 3], "/log 3"}], Row[{Subscript[Style["S", Italic], Row[{"bb,", 3}]], "/log 3"}], "mixed-box fraction", Row[{Style["L", Italic], "-fraction"}]};

(* ---------------------------------------------------------------------- *)
(* Locate result directory                                                 *)
(* ---------------------------------------------------------------------- *)

If[!ValueQ[resultDir],
  resultDir = If[Length[$ScriptCommandLine] >= 2,
    $ScriptCommandLine[[2]],
    SystemDialogInput["Directory"]
  ];
];

If[resultDir === $Canceled || !StringQ[resultDir] || !DirectoryQ[resultDir],
  Print["ERROR: resultDir is not a valid directory. Set resultDir before Get[...]."];
  Abort[];
];

submissionOutDir = FileNameJoin[{resultDir, submissionFigOutDirName}];
If[!DirectoryQ[submissionOutDir], CreateDirectory[submissionOutDir]];

Print["Result directory: ", resultDir];
Print["Output directory: ", submissionOutDir];

(* ---------------------------------------------------------------------- *)
(* Helpers                                                                 *)
(* ---------------------------------------------------------------------- *)

ClearAll[toNum, importCSVAssoc, assocNum, nearZQ, selectZ, zLabel, zTag, fmtNum];

toNum[x_?NumberQ] := N[x];
toNum[x_String] := Quiet@Check[N[ToExpression[StringReplace[x, {"," -> ""}]]], x];
toNum[x_] := Quiet@Check[N[x], x];

importCSVAssoc[file_String] := Module[{raw, header, rows},
  If[!FileExistsQ[file], Print["ERROR: file not found: ", file]; Abort[]];
  raw = Import[file, "CSV"];
  If[Length[raw] < 2, Print["ERROR: CSV has no data rows: ", file]; Abort[]];
  header = ToString /@ First[raw];
  rows = Rest[raw];
  AssociationThread[header, #] & /@ rows
];

assocNum[a_Association, key_String] := toNum[Lookup[a, key, Missing[key]]];
nearZQ[a_Association, z_?NumericQ] := NumericQ[assocNum[a, "z"]] && Abs[assocNum[a, "z"] - z] < 10^-8;
selectZ[rows_, z_?NumericQ] := Select[rows, nearZQ[#, z] &];

zLabel[z_?NumericQ] := If[Abs[z - 0.5] < 10^-8,
  Row[{"z = ", TraditionalForm[1/2]}],
  Row[{"z = ", NumberForm[z, {3, 2}]}]
];

zShortLabel[z_?NumericQ] := If[Abs[z - 0.5] < 10^-8, "z=1/2", "z=0.30"];
zTag[z_?NumericQ] := If[Abs[z - 0.5] < 10^-8, "z0p5", "z0p3"];
fmtNum[x_, digits_: 3] := ToString[NumberForm[N[x], {Infinity, digits}, NumberPadding -> {"", "0"}]];

ClearAll[classLegend, metricLegend];
classLegend[] := SwatchLegend[
  classColors,
  classLabels,
  LegendLayout -> "Row",
  LabelStyle -> {FontSize -> figLegendFont, FontFamily -> figFontFamily}
];
metricLegend[] := SwatchLegend[
  metricColors,
  metricLabels,
  LegendLayout -> "Row",
  LabelStyle -> {FontSize -> figLegendFont, FontFamily -> figFontFamily}
];

ClearAll[exportFigure];
exportFigure[base_String, fig_] := Module[{pdf, png, rpdf},
  pdf = base <> ".pdf";
  png = base <> ".png";
  rpdf = base <> "_raster.pdf";
  Quiet@Check[Export[pdf, fig, "PDF"], Print["WARNING: vector PDF export failed for ", base]];
  Quiet@Check[Export[png, Rasterize[fig, ImageResolution -> submissionFigureImageResolution], "PNG"],
    Print["WARNING: PNG export failed for ", base]];
  If[TrueQ[submissionExportRasterPDF],
    Quiet@Check[Export[rpdf, Rasterize[fig, ImageResolution -> submissionFigureImageResolution], "PDF"],
      Print["WARNING: raster PDF export failed for ", base]]
  ];
  Print["Exported: ", base, ".pdf/.png", If[TrueQ[submissionExportRasterPDF], "/_raster.pdf", ""]]
];

(* ---------------------------------------------------------------------- *)
(* Fig. 14--15: three-class slice plots                                     *)
(* ---------------------------------------------------------------------- *)

ClearAll[makeSlicePlot, tryImportWXF];

tryImportWXF[file_String] := If[FileExistsQ[file], Import[file], Missing["NotFound"]];

makeSlicePlot[mat_, z0_?NumericQ, figNo_String] := Module[{n, ticks, title},
  n = Length[mat];
  ticks = Table[{1 + (n - 1) v, Style[NumberForm[v, {2, 1}], figTickFont, FontFamily -> figFontFamily]}, {v, 0, 1, 0.5}];
  title = If[TrueQ[includeFigureNumberInPlotTitle],
    Row[{figNo, ".  Rule 210 three-class slice, ", zLabel[z0]}],
    Row[{"Rule 210 three-class slice, ", zLabel[z0]}]
  ];
  Legended[
    ArrayPlot[
      mat,
      ColorRules -> classColorRules,
      Frame -> True,
      FrameTicks -> {
        {Table[{1 + (n - 1) (1 - v), Style[NumberForm[v, {2, 1}], figTickFont, FontFamily -> figFontFamily]}, {v, 0, 1, 0.5}], None},
        {Table[{1 + (n - 1) v, Style[NumberForm[v, {2, 1}], figTickFont, FontFamily -> figFontFamily]}, {v, 0, 1, 0.5}], None}
      },
      FrameLabel -> {
        {Style["y", figLabelFont, FontFamily -> figFontFamily], None},
        {Style["x", figLabelFont, FontFamily -> figFontFamily], None}
      },
      PlotLabel -> Style[title, figTitleFont, Bold, FontFamily -> figFontFamily],
      ImageSize -> 760,
      ImagePadding -> {{90, 25}, {90, 65}},
      BaseStyle -> {FontSize -> figBaseFont, FontFamily -> figFontFamily},
      PlotRangePadding -> None
    ],
    Placed[classLegend[], Below]
  ]
];

labels05 = tryImportWXF[FileNameJoin[{resultDir, "fig14_15_labels_z0p5.wxf"}]];
labels03 = tryImportWXF[FileNameJoin[{resultDir, "fig14_15_labels_z0p3.wxf"}]];

If[labels05 =!= Missing["NotFound"],
  fig14Submission = makeSlicePlot[labels05, 0.5, "Fig. 14"];
  exportFigure[FileNameJoin[{submissionOutDir, "fig14_threeclass_z0p5_submission"}], fig14Submission],
  Print["Skipping Fig. 14: fig14_15_labels_z0p5.wxf not found."]
];

If[labels03 =!= Missing["NotFound"],
  fig15Submission = makeSlicePlot[labels03, 0.3, "Fig. 15"];
  exportFigure[FileNameJoin[{submissionOutDir, "fig15_threeclass_z0p3_submission"}], fig15Submission],
  Print["Skipping Fig. 15: fig14_15_labels_z0p3.wxf not found."]
];

(* Combined Fig. 14--15 is optional.  Individual panels are safer for manuscript insertion.
   The earlier Grid-of-Legended-graphics export may fail on some Mathematica versions. *)
If[ValueQ[exportCombinedFig14and15] && TrueQ[exportCombinedFig14and15] &&
    labels05 =!= Missing["NotFound"] && labels03 =!= Missing["NotFound"],
  fig14and15Combined = Grid[{{makeSlicePlot[labels05, 0.5, "(a)"], makeSlicePlot[labels03, 0.3, "(b)"]}}, Spacings -> {1.0, 0}];
  exportFigure[FileNameJoin[{submissionOutDir, "fig14_15_threeclass_slices_combined_submission"}], fig14and15Combined]
];

(* ---------------------------------------------------------------------- *)
(* Fig. 16: three-class uncertainty with binomial error bars                *)
(* ---------------------------------------------------------------------- *)

ClearAll[log10, xTickLabel, xTicks, xMinorTicks, yTicks, makeUncertaintyPanel, makeErrorBars];
log10[x_] := Log[10, x];

xTickLabel[v_] := Module[{e, m},
  e = Floor[Log[10, v]];
  m = Round[v/10.^e, 0.001];
  If[Abs[m - 1] < 10^-8,
    Superscript[10, e],
    Row[{NumberForm[m, {3, 1}], "\[Times]", Superscript[10, e]}]
  ]
];

xTicks[vals_List] := ({log10[#], Style[xTickLabel[#], figTickFont, FontFamily -> figFontFamily]} & /@ vals);
(* Minor ticks are drawn without labels to keep the log-scale x axis readable. *)
xMinorTicks[vals_List] := ({log10[#], "", {0.006, 0}, Directive[GrayLevel[0.35], AbsoluteThickness[0.8]]} & /@ vals);
yTicks[vals_List] := ({log10[#], Style[NumberForm[#, {3, 1}], figTickFont, FontFamily -> figFontFamily]} & /@ vals);

makeErrorBars[rows_] := Module[{cap = 0.025, eps, p, se, x, ylo, yhi},
  Flatten[
    Table[
      eps = assocNum[r, "Epsilon"]; p = assocNum[r, "P3"]; se = assocNum[r, "BinomialSE3"];
      If[!And[NumericQ[eps], NumericQ[p], NumericQ[se], p > 0],
        Nothing,
        x = log10[eps];
        ylo = log10[Max[p - se, 10^-12]];
        yhi = log10[Min[p + se, 1 - 10^-12]];
        {GrayLevel[0.35], AbsoluteThickness[1.2],
          Line[{{x, ylo}, {x, yhi}}],
          Line[{{x - cap, ylo}, {x + cap, ylo}}],
          Line[{{x - cap, yhi}, {x + cap, yhi}}]
        }
      ],
      {r, rows}
    ],
    1
  ]
];

makeUncertaintyPanel[pooledRows_, fitRows_, z0_?NumericQ] := Module[
  {rows, fit, pts, epsVals, pVals, seVals, xmin, xmax, ymin, ymax,
   gamma, gammaSE, db, r2, intercept, fitLine, annotation, yTickVals, xMajorTickVals, xMinorTickVals},
  rows = SortBy[selectZ[pooledRows, z0], assocNum[#, "Epsilon"] &];
  fit = Select[fitRows, nearZQ[#, z0] && ToString[Lookup[#, "FitType", ""]] == "ThreeClass" &];
  If[Length[rows] == 0 || Length[fit] == 0, Return[Graphics[Text["Missing data for z=" <> ToString[z0]]]]];
  fit = First[fit];
  epsVals = assocNum[#, "Epsilon"] & /@ rows;
  pVals = assocNum[#, "P3"] & /@ rows;
  seVals = assocNum[#, "BinomialSE3"] & /@ rows;
  pts = Transpose[{log10 /@ epsVals, log10 /@ pVals}];
  xmin = Min[log10 /@ epsVals]; xmax = Max[log10 /@ epsVals];
  ymin = Min[log10 /@ MapThread[Max[#1 - #2, 10^-12] &, {pVals, seVals}]] - 0.03;
  ymax = Max[log10 /@ MapThread[Min[#1 + #2, 1 - 10^-12] &, {pVals, seVals}]] + 0.03;
  gamma = assocNum[fit, "Gamma"]; gammaSE = assocNum[fit, "GammaSE"];
  db = assocNum[fit, "DbEstimate"]; r2 = assocNum[fit, "R2"]; intercept = assocNum[fit, "Intercept"];
  (* Intercept in fig16_threeclass_uncertainty_fit_summary.csv is in base-10 log units.
     Since both axes below are plotted in log10 coordinates, do not divide it by Log[10]. *)
  fitLine = Table[{xx, intercept + gamma xx}, {xx, xmin, xmax, (xmax - xmin)/200}];
  annotation = Framed[
    Column[
      {
        Row[{Style["\[Gamma]", Italic], " = ", fmtNum[gamma, 3], " \[PlusMinus] ", fmtNum[gammaSE, 3]}],
        Row[{Subscript[Style["D", Italic], "b"], " = ", fmtNum[db, 3]}],
        Row[{Superscript["R", 2], " = ", fmtNum[r2, 3]}]
      },
      Alignment -> Center,
      Spacings -> 0.35
    ],
    Background -> White,
    FrameStyle -> Directive[Black, AbsoluteThickness[1.2]],
    RoundingRadius -> 0,
    FrameMargins -> {{10, 10}, {8, 8}}
  ];
  (* Label only decade ticks on the x axis; draw intermediate ticks without labels. *)
  xMajorTickVals = {10^-4, 10^-3, 10^-2, 10^-1};
  xMinorTickVals = Select[
    Flatten[Table[m 10.^e, {e, -4, -1}, {m, 2, 9}]],
    xmin <= log10[#] <= xmax &
  ];
  yTickVals = Select[{0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8}, ymin <= log10[#] <= ymax &];
  Show[
    ListPlot[
      pts,
      PlotStyle -> Directive[RGBColor[0.05, 0.25, 0.80], PointSize[0.018]],
      Frame -> True,
      FrameTicks -> {{yTicks[yTickVals], None}, {Join[xTicks[xMajorTickVals], xMinorTicks[xMinorTickVals]], None}},
      FrameLabel -> {
        Style[Row[{"separation ", TraditionalForm[\[Epsilon]]}], figLabelFont, FontFamily -> figFontFamily],
        Style[Row[{"P(", TraditionalForm[\[Epsilon]], "), three-class"}], figLabelFont, FontFamily -> figFontFamily]
      },
      PlotLabel -> Style[zLabel[z0], figTitleFont, Bold, FontFamily -> figFontFamily],
      GridLines -> {log10 /@ xMajorTickVals, log10 /@ yTickVals},
      GridLinesStyle -> Directive[GrayLevel[0.86], AbsoluteThickness[0.7]],
      PlotRange -> {{xmin, xmax}, {ymin, ymax}},
      ImageSize -> 620,
      ImagePadding -> {{95, 30}, {90, 55}},
      BaseStyle -> {FontSize -> figBaseFont, FontFamily -> figFontFamily},
      Epilog -> {makeErrorBars[rows], Inset[Style[annotation, figAnnotationFont, FontFamily -> figFontFamily], Scaled[{0.64, 0.28}]]}
    ],
    ListLinePlot[fitLine, PlotStyle -> Directive[Black, Dashed, AbsoluteThickness[2.2]]]
  ]
];

pooledFile = FileNameJoin[{resultDir, "fig16_threeclass_uncertainty_pooled.csv"}];
fitFile = FileNameJoin[{resultDir, "fig16_threeclass_uncertainty_fit_summary.csv"}];
If[FileExistsQ[pooledFile] && FileExistsQ[fitFile],
  pooledRows = importCSVAssoc[pooledFile];
  fitRows = importCSVAssoc[fitFile];
  fig16Panels = makeUncertaintyPanel[pooledRows, fitRows, #] & /@ zOrderForSubmission;
  fig16Submission = Grid[{fig16Panels}, Spacings -> {1.0, 0}];
  exportFigure[FileNameJoin[{submissionOutDir, "fig16_threeclass_uncertainty_submission"}], fig16Submission],
  Print["Skipping Fig. 16: required CSV files not found."]
];

(* ---------------------------------------------------------------------- *)
(* Fig. 17: class fractions and three-class entropy                         *)
(* ---------------------------------------------------------------------- *)

ClearAll[groupedBarPlot, rowForZ, makeFig17Panels];

rowForZ[rows_, z_?NumericQ] := Module[{s = selectZ[rows, z]}, If[Length[s] == 0, Missing["NoZ"], First[s]]];

groupedBarPlot[rowsByZ_, seriesKeys_, seriesLabels_, colors_, yLabel_, legend_, opts : OptionsPattern[]] := Module[
  {nG, nS, barW, groupGap, centers, xMin, xMax, bars, ticks, yMax, panelLabel, title, panelText},
  nG = Length[rowsByZ]; nS = Length[seriesKeys];
  barW = 0.18; groupGap = 0.85;
  centers = Table[(g - 1) (nS barW + groupGap) + 1, {g, nG}];
  xMin = Min[centers] - nS barW; xMax = Max[centers] + nS barW;
  bars = Flatten[
    Table[
      With[{x = centers[[g]] + (s - (nS + 1)/2) barW*1.15,
            h = assocNum[rowsByZ[[g]], seriesKeys[[s]]],
            col = colors[[s]]},
        {EdgeForm[Directive[Black, AbsoluteThickness[0.6]]], col, Rectangle[{x - barW/2, 0}, {x + barW/2, h}]}
      ],
      {g, nG}, {s, nS}
    ],
    1
  ];
  ticks = Table[{centers[[g]], Style[zShortLabel[zOrderForSubmission[[g]]], figTickFont, FontFamily -> figFontFamily]}, {g, nG}];
  Legended[
    Graphics[
      bars,
      Frame -> True,
      FrameTicks -> {{Table[{v, Style[NumberForm[v, {2, 1}], figTickFont, FontFamily -> figFontFamily]}, {v, 0, 1, 0.2}], None}, {ticks, None}},
      FrameLabel -> {None, Style[yLabel, figLabelFont, FontFamily -> figFontFamily]},
      PlotRange -> {{xMin, xMax}, {0, 1.05}},
      ImageSize -> 650,
      ImagePadding -> {{95, 25}, {75, 30}},
      BaseStyle -> {FontSize -> figBaseFont, FontFamily -> figFontFamily},
      GridLines -> {None, Range[0, 1, 0.2]},
      GridLinesStyle -> Directive[GrayLevel[0.90], AbsoluteThickness[0.7]]
    ],
    Placed[legend, Above]
  ]
];

mainValuesFile = FileNameJoin[{resultDir, "fig17_threeclass_main_values.csv"}];
summaryFile = FileNameJoin[{resultDir, "fig17_threeclass_entropy_summary.csv"}];

If[FileExistsQ[mainValuesFile],
  mainRowsAll = importCSVAssoc[mainValuesFile];
  mainRows = rowForZ[mainRowsAll, #] & /@ zOrderForSubmission;
  If[MemberQ[mainRows, Missing["NoZ"]], Print["WARNING: Missing some z rows in fig17 main values."]];

  fig17ClassPanel = groupedBarPlot[
    mainRows,
    {"PlusFraction", "MinusFraction", "LineSetFraction", "StillOtherFraction"},
    classLabels,
    classColors,
    "class fraction",
    classLegend[]
  ];

  fig17EntropyPanel = groupedBarPlot[
    mainRows,
    {"S3OverLog3", "Sbb3OverLog3", "MixedBoxFraction3", "LineSetFraction"},
    metricLabels,
    metricColors,
    "normalized value / fraction",
    metricLegend[]
  ];

  fig17Submission = If[TrueQ[includePanelLabelsInFig17],
    Grid[
      {
        {Style["(a)", figTitleFont, Bold, FontFamily -> figFontFamily], fig17ClassPanel},
        {Style["(b)", figTitleFont, Bold, FontFamily -> figFontFamily], fig17EntropyPanel}
      },
      Alignment -> {Left, Center},
      Spacings -> {0.5, 0.9}
    ],
    Grid[{{fig17ClassPanel}, {fig17EntropyPanel}}, Alignment -> Center, Spacings -> {0, 0.9}]
  ];

  exportFigure[FileNameJoin[{submissionOutDir, "fig17_threeclass_summary_submission"}], fig17Submission];
  exportFigure[FileNameJoin[{submissionOutDir, "fig17a_threeclass_class_fractions_submission"}], fig17ClassPanel];
  exportFigure[FileNameJoin[{submissionOutDir, "fig17b_threeclass_entropy_submission"}], fig17EntropyPanel],
  Print["Skipping Fig. 17 main panels: fig17_threeclass_main_values.csv not found."]
];

(* ---------------------------------------------------------------------- *)
(* Optional Appendix figure: resolution/sampling dependence                 *)
(* ---------------------------------------------------------------------- *)

ClearAll[makeResolutionPanel, makeResolutionSweepFigure];

makeResolutionPanel[rows_, z0_?NumericQ, metricKey_String, yText_String] := Module[
  {sub, samples, colors, markers, series, legend, boxesVals},
  sub = SortBy[selectZ[rows, z0], {assocNum[#, "SamplesPerBox"] &, assocNum[#, "Boxes"] &}];
  samples = Sort[DeleteDuplicates[assocNum[#, "SamplesPerBox"] & /@ sub]];
  colors = {Black, GrayLevel[0.5], RGBColor[0.10, 0.32, 0.85], RGBColor[0.85, 0.10, 0.10]};
  markers = {"\[FilledCircle]", "\[FilledSquare]", "\[FilledUpTriangle]", "\[FilledDiamond]"};
  series = Table[
    ({assocNum[#, "Boxes"], assocNum[#, metricKey]} & /@ SortBy[Select[sub, assocNum[#, "SamplesPerBox"] == m &], assocNum[#, "Boxes"] &]),
    {m, samples}
  ];
  ListLinePlot[
    series,
    PlotStyle -> Table[Directive[colors[[Mod[i - 1, Length[colors]] + 1]], AbsoluteThickness[2.0]], {i, Length[series]}],
    PlotMarkers -> (Style[#, 13] & /@ Take[markers, Length[series]]),
    Frame -> True,
    FrameLabel -> {
      Style["number of boxes per axis", figTickFont, FontFamily -> figFontFamily],
      Style[yText, figTickFont, FontFamily -> figFontFamily]
    },
    PlotRange -> {{All, All}, {0, 1.05}},
    FrameTicksStyle -> Directive[figTickFont - 2, FontFamily -> figFontFamily],
    GridLines -> {Automatic, Range[0, 1, 0.2]},
    GridLinesStyle -> Directive[GrayLevel[0.90], AbsoluteThickness[0.6]],
    ImageSize -> 400,
    ImagePadding -> {{70, 20}, {70, 30}},
    PlotLegends -> Placed[LineLegend[("m = " <> ToString[#] & /@ samples), LegendLayout -> "Row", LabelStyle -> {FontSize -> figTickFont - 1, FontFamily -> figFontFamily}], Below],
    BaseStyle -> {FontSize -> figTickFont, FontFamily -> figFontFamily}
  ]
];

makeResolutionSweepFigure[rows_, z0_?NumericQ] := Module[{panels},
  panels = {
    makeResolutionPanel[rows, z0, "S3OverLog3", "S3/log 3"],
    makeResolutionPanel[rows, z0, "Sbb3OverLog3", "Sbb3/log 3"],
    makeResolutionPanel[rows, z0, "MixedBoxFraction3", "mixed-box fraction"],
    makeResolutionPanel[rows, z0, "LineSetFraction", "L-fraction"]
  };
  Labeled[
    Grid[Partition[panels, 2], Spacings -> {0.8, 0.8}],
    Style[Row[{"Resolution dependence, ", zLabel[z0]}], figTitleFont, Bold, FontFamily -> figFontFamily],
    Top
  ]
];

If[FileExistsQ[summaryFile],
  summaryRows = importCSVAssoc[summaryFile];
  Do[
    sweepFig = makeResolutionSweepFigure[summaryRows, z0];
    exportFigure[FileNameJoin[{submissionOutDir, "fig17_resolution_sweep_" <> zTag[z0] <> "_submission"}], sweepFig],
    {z0, zOrderForSubmission}
  ],
  Print["Skipping resolution sweep: fig17_threeclass_entropy_summary.csv not found."]
];

Print["Done. Submission figures are in: ", submissionOutDir];
